# ABH Browser

Android browser with a folder downloader. **Long-press a folder link** and every mp3/video inside it (subfolders included) is downloaded into `Downloads/ABH browser/<folder>/...`.

## Features
- Home screen with search box and quick links
- Multiple tabs, back/forward, reload
- Bookmarks, history, desktop-site mode, settings (search engine, parallel downloads)
- Downloads inside the app: progress dialog, notification, foreground service, download list
- Fast folder crawl (parallel fetch) with automatic compatibility fallback
- Already-downloaded files are skipped on the next run
- Detects videos while a page plays (blue ⬇ button) incl. unencrypted HLS streams; DRM/YouTube-style services are not supported
- Long-press a video: quality picker (240p/360p/720p...) with a double tick on qualities already downloaded
- Opens http/https links from other apps

## Build
**GitHub:** push the repo, then Actions > "Build APK" > download the APK artifact.
**Android Studio:** File > Open this folder > Run.

The APK is signed with the key in `app/abh.keystore`, so every new build installs over the old one.
(If you installed a build made before this key was added, uninstall it once.)

## Notes
- Pages that need login may not crawl.
- Only download content you have permission to download.
