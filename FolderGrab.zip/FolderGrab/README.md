# FolderGrab

Simple Android browser app. **Tap** a folder link to open it. **Long-press** a folder link to download every mp3/video inside it (subfolders included).

Works with open-directory pages ("Index of /...") that list files as plain HTML links.

## Features
- Built-in WebView browser with URL bar
- Long-press a folder to crawl and download all media files
- Keeps folder structure in `Downloads/FolderGrab/<folder>/...`
- Uses Android's DownloadManager (notifications, resume, retry)
- No third-party dependencies

## Build
**Android Studio:** File > Open this folder > Run.
**GitHub:** push the repo, then Actions > "Build APK" > download the APK artifact.

## Customize
Edit the `exts` set in `MainActivity.kt` to change file types.

## Limits
- Pages that need login or load their file list with JavaScript are not crawled.
- Only download content you have permission to download.
