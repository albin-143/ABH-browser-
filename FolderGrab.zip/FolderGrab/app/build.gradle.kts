plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.foldergrab"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.foldergrab"
        minSdk = 24
        targetSdk = 34
        // Every build gets a higher versionCode, so new APK installs over the old one
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "2.0"
    }
    // Fixed signing key (kept in the repo) so updates install over the old app
    signingConfigs {
        create("abh") {
            storeFile = file("abh.keystore")
            storePassword = "abhbrowser"
            keyAlias = "abh"
            keyPassword = "abhbrowser"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("abh") }
        getByName("release") { signingConfig = signingConfigs.getByName("abh") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
