package com.example.foldergrab

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Folder crawl + in-app downloader.
 * Maraivaana browser (view) vazhiya pages-a padikkum, files-a download pannum.
 */
class Grabber(private val act: Activity, private val store: Store) {

    val view: WebView = WebView(act)            // 1x1 hidden browser
    private val handler = Handler(Looper.getMainLooper())   // downloads
    private val ch = Handler(Looper.getMainLooper())        // crawl timers

    private val appFolder = "ABH browser"        // Downloads/ABH browser/...
    private val channelId = MainActivity.CHANNEL
    private val nm = act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private val exts = setOf("mp3", "m4a", "wav", "flac", "aac", "ogg", "wma",
        "mp4", "mkv", "webm", "avi", "mov", "3gp")

    private class Job(val url: String, val rel: String, val depth: Int)
    private class Report {
        var pages = 0
        var links = 0
        var last: List<String> = emptyList()
        var error: String? = null
    }
    private class Dl(val url: String, val rel: String, val page: String)
    private class Slot(val seq: Int, val dl: Dl) {
        var name = ""
        @Volatile var out: OutputStream? = null
        var uri: Uri? = null
        var file: File? = null
        @Volatile var ioErr: String? = null
        @Volatile var bytes = 0L
        @Volatile var lastAct = 0L
    }

    // ---- crawl state ----
    private var mode = 0                 // 0 idle, 1 fast-loading, 2 fast-running, 3 slow
    private var running = false
    private var stopping = false
    private var crawlSeq = 0
    private var lastCrawlAct = 0L
    private var crawlHost = ""
    private var rootLink = ""
    private var multi = false                      // picker-la therndhedutha folders
    private var multiRoots: List<String> = emptyList()
    private val found = LinkedHashMap<String, String>()   // url -> relative folder
    private val refs = HashMap<String, String>()          // url -> page url (Referer)
    private var rep = Report()
    private var progress: AlertDialog? = null
    private var progressText: TextView? = null
    // slow (compatibility) mode
    private val queue = ArrayList<Job>()
    private val seen = HashSet<String>()
    private var current: Job? = null
    private var loadToken = 0
    private var scheduledToken = -1

    // ---- download state ----
    private val dlQueue = ArrayList<Dl>()
    private val slots = ConcurrentHashMap<Int, Slot>()
    private var seqGen = 0
    private var dlRunning = false
    private var loadingPage = false
    private var dlPage = ""
    private var dlToken = 0
    private var dlTotal = 0
    private var dlOk = 0
    private var dlFail = 0
    private val dlErrors = ArrayList<String>()
    private var dlPaused = false
    var onOpenPage: ((String) -> Unit)? = null

    // Downloads page (full screen)
    private var pageDlg: Dialog? = null
    private var pSummary: TextView? = null
    private var pActive: TextView? = null
    private var pBar: ProgressBar? = null
    private var pPause: TextView? = null
    private var pStop: TextView? = null
    private var pList: ListView? = null
    private var pAdapter: ArrayAdapter<String>? = null
    private var pLog: List<Store.DlItem> = emptyList()
    private var pLastKey = ""

    // ---------- JavaScript ----------
    // Fast crawl: browser kulla irundhu fetch() vachu pala pages-a ore neram-la padikkum
    private val crawlJs = """
(async function(seq,CONC){
 var EX=/\.(mp3|m4a|wav|flac|aac|ogg|wma|mp4|mkv|webm|avi|mov|3gp)${'$'}/i;
 var base=location.href, loc=new URL(base), lh=loc.hostname.replace(/^www\./,'');
 window.__abhStop=false;
 var PFX=__PFX__;
 var seen={}, found={}, files=[], pages=0, active=0, errs=[];
 function norm(u){ try{ var x=new URL(u); if(x.hostname.replace(/^www\./,'')===lh){ return loc.origin+x.pathname+x.search; } return x.href; }catch(e){ return null; } }
 function isMedia(u){ try{ var x=new URL(u); if(EX.test(x.pathname)) return true; var f=false; x.searchParams.forEach(function(v){ if(EX.test(v)) f=true; }); return f; }catch(e){ return false; } }
 function bad(s){ return s.replace(/[\\:*?"<>|]/g,'_'); }
 function dec(s){ try{ return decodeURIComponent(s.replace(/\+/g,'%2B')); }catch(e){ return s; } }
 function fname(u){ try{ var x=new URL(u); var p=x.pathname.split('/').pop(); if(EX.test(p)) return bad(dec(p)); var r=''; x.searchParams.forEach(function(v){ if(!r && EX.test(v)) r=v.split('/').pop(); }); return bad(dec(r||p))||'file'; }catch(e){ return 'file'; } }
 function fold(u){ try{
   var x=new URL(u); var last=x.pathname.replace(/\/+${'$'}/,'').split('/').pop(); var q='';
   var keys=['folder','page','album','dir','cat','category','id','name','title'];
   for(var i=0;i<keys.length;i++){ var v=x.searchParams.get(keys[i]); if(v){ q=v; break; } }
   if(!q && last.indexOf('.')>=0){ var all=Array.from(x.searchParams.keys()); if(all.length) q=x.searchParams.get(all[all.length-1])||''; }
   var raw=q||last; var s=raw.replace(/\/+${'$'}/,'').split('/').pop(); return bad(dec(s))||'folder';
 }catch(e){ return 'folder'; } }
 function isSub(cur,c){ try{
   var a=new URL(cur), b=new URL(c);
   if(a.hostname.replace(/^www\./,'')!==b.hostname.replace(/^www\./,'')) return false;
   var cf=a.searchParams.get('folder'), nf=b.searchParams.get('folder');
   if(nf!==null && cf!==null){ return a.pathname===b.pathname && nf!==cf && nf.indexOf(cf.replace(/\/+${'$'}/,'')+'/')===0; }
   if(nf!==null && cf===null){ var ad=a.pathname.replace(/[^\/]*${'$'}/,''); var bd=b.pathname.replace(/[^\/]*${'$'}/,''); return ad===bd && nf!==''; }
   var pre=a.pathname.replace(/\/+${'$'}/,'')+'/'; var last=b.pathname.replace(/\/+${'$'}/,'').split('/').pop();
   return b.pathname.indexOf(pre)===0 && b.pathname!==pre && (/\/${'$'}/.test(b.pathname) || last.indexOf('.')<0);
 }catch(e){ return false; } }
 function add(u,job,names){ if(found[u]) return; found[u]=1; names[fname(u)]=1; files.push([u,job.rel,job.u]); }
 var roots=__ROOTS__, q=[];
 for(var ri=0;ri<roots.length;ri++){ var rn=norm(roots[ri]); if(rn && !seen[rn]){ seen[rn]=1; q.push({u:rn,rel:PFX+fold(rn)+'/',d:0}); } }
 async function doPage(job){
   var r, html;
   try{ r=await fetch(job.u,{credentials:'include'}); if(!r.ok){ errs.push('HTTP '+r.status); return; } html=await r.text(); }
   catch(e){ errs.push(String(e)); return; }
   pages++;
   var pb=r.url||job.u, doc=new DOMParser().parseFromString(html,'text/html'), links={}, names={};
   doc.querySelectorAll('a[href],[src],source,[data-src],[data-url]').forEach(function(e){
     ['href','src','data-src','data-url'].forEach(function(a){
       var v=e.getAttribute(a);
       if(v){ try{ var n=norm(new URL(v,pb).href.split('#')[0]); if(n) links[n]=1; }catch(x){} }
     });
   });
   Object.keys(links).forEach(function(l){
     if(isMedia(l)) add(l,job,names);
     else if(isSub(pb,l) && !seen[l]){ seen[l]=1; q.push({u:l,rel:job.rel+fold(l)+'/',d:job.d+1}); }
   });
   var re=/["'(]([^"'()\s<>]+\.(?:mp3|m4a|wav|flac|aac|ogg|wma|mp4|mkv|webm|avi|mov|3gp)(?:\?[^"'()\s<>]*)?)["')]/gi, m;
   while((m=re.exec(html))){ try{ var u=norm(new URL(m[1].replace(/&amp;/g,'&'),pb).href); if(u && !found[u] && !names[fname(u)]) add(u,job,names); }catch(x){} }
 }
 function sleep(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }
 async function worker(){
   for(;;){
     if(window.__abhStop) return;
     var job=q.shift();
     if(!job){ if(active===0) return; await sleep(40); continue; }
     if(job.d>8) continue;
     active++;
     try{ await doPage(job); }finally{ active--; }
     ABH.progress(seq,pages,files.length,job.rel);
   }
 }
 try{
   var ws=[]; for(var i=0;i<CONC;i++) ws.push(worker());
   await Promise.all(ws);
   for(var i=0;i<files.length;i+=400){ ABH.files(seq,JSON.stringify(files.slice(i,i+400))); }
   ABH.crawlDone(seq,pages,errs.slice(0,3).join(' | '));
 }catch(e){ ABH.crawlDone(seq,pages,'JS error: '+e); }
})(__SEQ__,__CONC__);
"""

    // Slow (compatibility) mode: page-a render panni links edukkum
    private val js = """
(function(){
 var L=[],M={};
 document.querySelectorAll('a[href],[src],source,audio,video,[data-src],[data-url]').forEach(function(e){
   ['href','src','data-src','data-url'].forEach(function(a){
     var v=e.getAttribute(a);
     if(v){ try{ L.push(new URL(v,document.baseURI).href); }catch(x){} }
   });
 });
 var h=document.documentElement.outerHTML;
 var re=/["'(]([^"'()\s<>]+\.(?:mp3|m4a|wav|flac|aac|ogg|wma|mp4|mkv|webm|avi|mov|3gp)(?:\?[^"'()\s<>]*)?)["')]/gi, m;
 while((m=re.exec(h))){ try{ M[new URL(m[1].replace(/&amp;/g,'&'),document.baseURI).href]=1; }catch(x){} }
 return JSON.stringify({u:location.href,l:L,m:Object.keys(M)});
})()
"""

    // Browser session-la irundhu file-a stream panni app-ku anuppum
    private val fetchJs = """
(async function(url,seq){
 try{
  var r=await fetch(url,{credentials:'include'});
  if(!r.ok){ ABH.fail(seq,'HTTP '+r.status); return; }
  var rd=r.body.getReader(),total=0;
  while(true){
   if(window.__abhX && window.__abhX[seq]){ try{ rd.cancel(); }catch(e){} return; }
   var x=await rd.read();
   if(x.done) break;
   var v=x.value,bin='';
   for(var i=0;i<v.length;i+=32768){ bin+=String.fromCharCode.apply(null,v.subarray(i,i+32768)); }
   ABH.chunk(seq,btoa(bin)); total+=v.length;
  }
  ABH.done(seq,''+total);
 }catch(e){ ABH.fail(seq,''+e); }
})(__URL__,__SEQ__);
"""

    inner class Bridge {
        // ----- crawl -----
        @JavascriptInterface
        fun progress(seq: Int, pages: Int, files: Int, label: String) {
            handler.post {
                if (running && seq == crawlSeq && mode == 2) {
                    lastCrawlAct = System.currentTimeMillis()
                    rep.pages = pages
                    progressText?.text = "Pages: $pages     Files: $files\n\n$label"
                }
            }
        }

        @JavascriptInterface
        fun files(seq: Int, json: String) {
            try {
                val a = JSONArray(json)
                val tmp = ArrayList<Array<String>>()
                for (i in 0 until a.length()) {
                    val r = a.getJSONArray(i)
                    tmp.add(arrayOf(r.getString(0), r.getString(1), r.getString(2)))
                }
                handler.post {
                    if (running && seq == crawlSeq) {
                        for (t in tmp) if (!found.containsKey(t[0])) { found[t[0]] = t[1]; refs[t[0]] = t[2] }
                    }
                }
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun crawlDone(seq: Int, pages: Int, err: String) {
            handler.post { onFastDone(seq, pages, err) }
        }

        // ----- download -----
        @JavascriptInterface
        fun chunk(seq: Int, b64: String) {
            val s = slots[seq] ?: return
            try {
                val data = Base64.decode(b64, Base64.DEFAULT)
                s.out?.write(data)
                s.bytes += data.size
                s.lastAct = System.currentTimeMillis()
            } catch (e: Exception) { s.ioErr = e.toString() }
        }

        @JavascriptInterface
        fun done(seq: Int, total: String) { handler.post { finishFile(seq, null) } }

        @JavascriptInterface
        fun fail(seq: Int, msg: String) { handler.post { finishFile(seq, msg) } }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!dlRunning) return
            refreshUi()
            handler.postDelayed(this, 1000)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (dlRunning) {
                for (s in slots.values.toList()) if (now - s.lastAct > 60000) finishFile(s.seq, "Timeout")
            }
            if (running && mode == 2 && now - lastCrawlAct > 90000) onFastDone(crawlSeq, rep.pages, "Timeout")
            handler.postDelayed(this, 10000)
        }
    }

    init {
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.blockNetworkImage = true       // vegama irukka: images load aagaadhu
        view.addJavascriptInterface(Bridge(), "ABH")
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { onCrawlerLoaded() }

            override fun shouldInterceptRequest(v: WebView?, req: WebResourceRequest?): WebResourceResponse? {
                val u = req?.url ?: return null
                val host = (u.host ?: "").removePrefix("www.")
                val path = (u.path ?: "").lowercase()
                val img = path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".png") ||
                    path.endsWith(".gif") || path.endsWith(".webp") || path.endsWith(".svg") ||
                    path.endsWith(".ico") || path.endsWith(".woff") || path.endsWith(".woff2")
                if ((crawlHost.isNotEmpty() && host != crawlHost) || img) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
        }
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Downloads", NotificationManager.IMPORTANCE_LOW))
        }
        handler.postDelayed(watchdog, 10000)
    }

    // ---------- helpers ----------
    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun hostOf(u: String) = try { URL(u).host.removePrefix("www.") } catch (e: Exception) { "" }
    private fun pathOf(u: String) = try { URL(u).path ?: "" } catch (e: Exception) { "" }
    private fun extOf(s: String) = s.substringBefore('?').substringAfterLast('.', "").lowercase()

    private fun isMedia(u: String): Boolean {
        if (extOf(pathOf(u)) in exts) return true
        return try {
            val uri = Uri.parse(u)
            uri.queryParameterNames.any { extOf(uri.getQueryParameter(it) ?: "") in exts }
        } catch (e: Exception) { false }
    }

    private fun fileName(u: String): String {
        val p = pathOf(u).substringAfterLast('/')
        if (extOf(p) in exts) return decode(p)
        try {
            val uri = Uri.parse(u)
            for (n in uri.queryParameterNames) {
                val v = uri.getQueryParameter(n) ?: continue
                if (extOf(v) in exts) return decode(v.substringAfterLast('/'))
            }
        } catch (e: Exception) { }
        return decode(p).ifEmpty { "file" }
    }

    private fun folderName(u: String): String {
        val uri = try { Uri.parse(u) } catch (e: Exception) { null }
        val lastSeg = pathOf(u).trimEnd('/').substringAfterLast('/')
        var q = ""
        if (uri != null) {
            val names = uri.queryParameterNames
            for (k in listOf("folder", "page", "album", "dir", "cat", "category", "id", "name", "title")) {
                if (names.contains(k)) { q = uri.getQueryParameter(k) ?: ""; if (q.isNotEmpty()) break }
            }
            if (q.isEmpty() && lastSeg.contains('.') && names.isNotEmpty()) {
                q = uri.getQueryParameter(names.last()) ?: ""
            }
        }
        val raw = if (q.isNotEmpty()) q else lastSeg
        return decode(raw.trimEnd('/').substringAfterLast('/')).ifEmpty { "folder" }
    }

    private fun isSubfolder(cur: String, c: String): Boolean {
        val cu = try { URL(cur) } catch (e: Exception) { return false }
        val cc = try { URL(c) } catch (e: Exception) { return false }
        if (cu.host.removePrefix("www.") != cc.host.removePrefix("www.")) return false
        val cf = Uri.parse(cur).getQueryParameter("folder")
        val nf = Uri.parse(c).getQueryParameter("folder")
        if (nf != null && cf != null) {
            return cu.path == cc.path && nf.startsWith(cf.trimEnd('/') + "/") && nf != cf
        }
        if (nf != null && cf == null) {
            val curDir = if (cu.path.endsWith("/")) cu.path else cu.path.substringBeforeLast('/') + "/"
            val candDir = cc.path.substringBeforeLast('/') + "/"
            return curDir == candDir && nf.isNotEmpty()
        }
        val dirPrefix = cu.path.trimEnd('/') + "/"
        val last = cc.path.trimEnd('/').substringAfterLast('/')
        return cc.path.startsWith(dirPrefix) && cc.path != dirPrefix &&
            (cc.path.endsWith("/") || !last.contains('.'))
    }

    private fun decode(s: String) =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }
            .replace(Regex("""[\\:*?"<>|]"""), "_")

    private fun mimeOf(name: String) = when (extOf(name)) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "wav" -> "audio/x-wav"
        "flac" -> "audio/flac"
        "aac" -> "audio/aac"
        "ogg" -> "audio/ogg"
        "wma" -> "audio/x-ms-wma"
        "mp4" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "avi" -> "video/x-msvideo"
        "mov" -> "video/quicktime"
        "3gp" -> "video/3gpp"
        else -> "application/octet-stream"
    }

    // ---------- public entry points ----------
    fun confirmAndGrab(link: String, page: String) {
        if (running) { toast("Thedura vela innum odikittu irukku"); return }
        if (isMedia(link)) { downloadSingle(link, page); return }
        if (dlRunning) { toast("Download mudiyura varaikum kaathirunga (alladhu Stop pannunga)"); return }
        AlertDialog.Builder(act)
            .setTitle("Files-a thedava?")
            .setMessage("$link\n\nIntha folder (subfolders ulla) la ulla media files-a thedi count kaattuven.")
            .setPositiveButton("Thedu") { _, _ -> startCrawl(link) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun downloadSingle(url: String, page: String) {
        AlertDialog.Builder(act)
            .setTitle("Download pannava?")
            .setMessage(fileName(url))
            .setPositiveButton("Download") { _, _ -> enqueue(listOf(Dl(url, "", page))) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showDownloads() {
        pageDlg?.dismiss()
        val d = Dialog(act, android.R.style.Theme_Material_Light_NoActionBar)
        fun btn(label: String, onClick: () -> Unit): TextView = TextView(act).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            background = rounded(0xFFEDEDED.toInt(), 10)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { onClick() }
        }
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val head = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(14), dp(12), dp(10))
        }
        head.addView(TextView(act).apply {
            text = "←"; textSize = 26f
            setPadding(dp(12), 0, dp(16), 0)
            setOnClickListener { d.dismiss() }
        })
        head.addView(TextView(act).apply {
            text = "Downloads"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(btn("Clear list") { store.clearDownloadsLog(); pLastKey = ""; refreshPage() })
        root.addView(head, LinearLayout.LayoutParams(-1, -2))

        val ctl = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(4), dp(12), dp(8))
        }
        pPause = btn("⏸  Pause") { togglePause() }
        pStop = btn("■  Stop") { stopDownloads() }
        val lp1 = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(6), 0) }
        val lp2 = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, 0, 0) }
        ctl.addView(pPause, lp1)
        ctl.addView(pStop, lp2)
        root.addView(ctl, LinearLayout.LayoutParams(-1, -2))

        pBar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        root.addView(pBar, LinearLayout.LayoutParams(-1, dp(6)))
        pSummary = TextView(act).apply { textSize = 15f; setPadding(dp(16), dp(10), dp(16), dp(4)) }
        root.addView(pSummary, LinearLayout.LayoutParams(-1, -2))
        pActive = TextView(act).apply {
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(dp(16), dp(2), dp(16), dp(8))
        }
        root.addView(pActive, LinearLayout.LayoutParams(-1, -2))

        val adapter = ArrayAdapter<String>(act, android.R.layout.simple_list_item_1, ArrayList<String>())
        pAdapter = adapter
        val lv = ListView(act)
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ -> if (pos < pLog.size) openFile(pLog[pos]) }
        lv.setOnItemLongClickListener { _, _, pos, _ -> if (pos < pLog.size) itemMenu(pLog[pos]); true }
        pList = lv
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))

        d.setContentView(root)
        d.setOnDismissListener { pageDlg = null }
        pageDlg = d
        pLastKey = ""
        d.show()
        d.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        refreshPage()
    }

    private fun itemMenu(x: Store.DlItem) {
        val labels = arrayOf("▶  Open file", "🌐  Open source page", "🗑  Remove from list")
        AlertDialog.Builder(act).setTitle(x.name).setItems(labels) { _, i ->
            when (i) {
                0 -> openFile(x)
                1 -> {
                    if (x.page.isNotEmpty()) { pageDlg?.dismiss(); onOpenPage?.invoke(x.page) }
                    else toast("Source page theriyala")
                }
                2 -> { store.removeDownload(x); pLastKey = ""; refreshPage() }
                else -> { }
            }
        }.show()
    }

    private fun refreshPage() {
        if (pageDlg == null) return
        val doneN = dlOk + dlFail
        pSummary?.text = if (dlRunning)
            "$doneN / $dlTotal    •    OK $dlOk    •    Fail $dlFail" + (if (dlPaused) "    •    PAUSED" else "")
        else "Download edhuvum odala"
        pBar?.max = maxOf(dlTotal, 1)
        pBar?.progress = if (dlRunning) doneN else 0
        val active = slots.values.joinToString("\n") { "↓ " + it.name + "   " + (it.bytes / 1024) + " KB" }
        val errs = if (dlErrors.isNotEmpty()) "\n\nErrors:\n" + dlErrors.takeLast(3).joinToString("\n") else ""
        pActive?.text = (if (dlPaused && slots.isNotEmpty()) "Pause aaguthu - ippo irukkura files mudiyattum...\n" else "") + active + errs
        pPause?.text = if (dlPaused) "▶  Resume" else "⏸  Pause"
        val vis = if (dlRunning) View.VISIBLE else View.GONE
        pPause?.visibility = vis
        pStop?.visibility = vis
        val key = "$doneN|$dlRunning|$dlPaused"
        if (key != pLastKey) {
            pLastKey = key
            pLog = store.downloads()
            val ad = pAdapter
            if (ad != null) {
                ad.clear()
                ad.addAll(pLog.map { (if (it.ok) "✔  " else "✖  ") + it.rel + it.name })
                ad.notifyDataSetChanged()
            }
        }
    }

    fun togglePause() {
        if (!dlRunning) return
        dlPaused = !dlPaused
        if (!dlPaused) pump()
        refreshUi()
    }

    private fun openFile(x: Store.DlItem) {
        if (!x.ok) { toast("Intha file download aagala"); return }
        if (x.uri.isEmpty()) { toast("Downloads/$appFolder/${x.rel}${x.name}"); return }
        try {
            act.startActivity(Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(x.uri), mimeOf(x.name))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { toast("Open panna mudiyala") }
    }

    // =====================================================================
    //  CRAWL
    // =====================================================================
    private fun startCrawl(link: String, roots: List<String>? = null) {
        found.clear(); refs.clear(); queue.clear(); seen.clear(); rep = Report()
        rootLink = link
        multi = roots != null
        multiRoots = roots ?: emptyList()
        stopping = false
        running = true
        mode = 1
        crawlSeq++
        crawlHost = hostOf(link)
        progressText = TextView(act).apply { setPadding(48, 32, 48, 16); text = "Page thirakkuthu..." }
        progress = AlertDialog.Builder(act)
            .setTitle("Files-a thedureen")
            .setView(progressText)
            .setCancelable(false)
            .setNegativeButton("Stop") { _, _ -> stopCrawl() }
            .show()
        view.loadUrl(link)
        val sq = crawlSeq
        ch.postDelayed({
            if (running && mode == 1 && sq == crawlSeq) { mode = 2; runFastCrawl() }
        }, 30000)
    }

    private fun stopCrawl() {
        if (!running) return
        stopping = true
        if (mode == 2) {
            view.evaluateJavascript("window.__abhStop=true;", null)
            ch.postDelayed({ if (running && stopping) finishCrawl() }, 8000)
            toast("Niruththuren...")
        } else {
            finishCrawl()
        }
    }

    private fun onCrawlerLoaded() {
        if (dlRunning) { onDlPageLoaded(); return }
        if (!running) return
        when (mode) {
            1 -> {
                mode = 2
                ch.postDelayed({ if (running && mode == 2) runFastCrawl() }, 300)
            }
            3 -> {
                val t = loadToken
                if (scheduledToken == t) return
                scheduledToken = t
                ch.postDelayed({ extract(t) }, 800)
            }
        }
    }

    private fun runFastCrawl() {
        lastCrawlAct = System.currentTimeMillis()
        val rootsJs = if (multi) JSONArray(multiRoots).toString() else "[location.href]"
        val pfx = if (multi) JSONObject.quote(folderName(rootLink) + "/") else "\"\""
        val script = crawlJs.replace("__SEQ__", crawlSeq.toString()).replace("__CONC__", "6")
            .replace("__ROOTS__", rootsJs).replace("__PFX__", pfx)
        view.evaluateJavascript(script, null)
    }

    private fun onFastDone(seq: Int, pages: Int, err: String) {
        if (!running || seq != crawlSeq || mode != 2) return
        rep.pages = pages
        if (err.isNotEmpty()) rep.error = err
        if (found.isEmpty() && !stopping && !multi) { startSlow(); return }   // compatibility fallback
        finishCrawl()
    }

    private fun startSlow() {
        ch.removeCallbacksAndMessages(null)
        mode = 3
        progressText?.text = "Compatibility mode (konjam melle)..."
        queue.clear(); seen.clear()
        queue.add(Job(rootLink, folderName(rootLink) + "/", 0))
        next()
    }

    private fun next() {
        if (!running || mode != 3) return
        var job: Job? = null
        while (queue.isNotEmpty()) {
            val j = queue.removeAt(0)
            if (j.depth <= 8 && seen.add(j.url)) { job = j; break }
        }
        if (job == null) { finishCrawl(); return }
        current = job
        val t = ++loadToken
        progressText?.text = "Pages: ${rep.pages}     Files: ${found.size}\n\n${job.rel}"
        view.loadUrl(job.url)
        ch.postDelayed({
            if (running && mode == 3 && t == loadToken) { scheduledToken = t; extract(t) }
        }, 30000)
    }

    private fun extract(t: Int) {
        if (!running || mode != 3 || t != loadToken) return
        view.evaluateJavascript(js) { res -> onExtracted(t, res) }
    }

    private fun onExtracted(t: Int, res: String?) {
        if (!running || mode != 3 || t != loadToken) return
        loadToken++
        val job = current ?: return
        try {
            val s = JSONTokener(res ?: "null").nextValue()
            if (s is String) handlePage(job, JSONObject(s)) else rep.error = "Page data kidaikala"
        } catch (e: Exception) {
            rep.error = e.toString()
        }
        ch.post { next() }
    }

    private fun handlePage(job: Job, o: JSONObject) {
        val pageUrl = o.optString("u", job.url)
        val links = o.getJSONArray("l")
        val media = o.getJSONArray("m")
        rep.pages++
        val uniq = LinkedHashSet<String>()
        for (i in 0 until links.length()) uniq.add(links.getString(i).substringBefore('#'))
        rep.links += uniq.size
        rep.last = uniq.toList().takeLast(15)
        for (l in uniq) {
            if (isMedia(l)) {
                if (!found.containsKey(l)) { found[l] = job.rel; refs[l] = pageUrl }
            } else if (isSubfolder(pageUrl, l)) {
                queue.add(Job(l, job.rel + folderName(l) + "/", job.depth + 1))
            }
        }
        val names = HashSet<String>()
        for ((u, r) in found) if (r == job.rel) names.add(fileName(u))
        for (i in 0 until media.length()) {
            val m = media.getString(i)
            val n = fileName(m)
            if (!found.containsKey(m) && n !in names) { found[m] = job.rel; refs[m] = pageUrl; names.add(n) }
        }
    }

    private fun finishCrawl() {
        running = false
        mode = 0
        current = null
        stopping = false
        loadToken++
        ch.removeCallbacksAndMessages(null)
        progress?.dismiss(); progress = null
        showResult()
    }

    // Media illaadha page (Star Hits maathiri): ulla folder links-a list-a kaattum
    private val candJs = """
(function(){
 var base=location.href, loc=new URL(base), lh=loc.hostname.replace(/^www\./,'');
 var skip='nav,aside,header,footer,[class*=menu],[id*=menu],[class*=sidebar],[id*=sidebar],[class*=nav],[id*=nav],[class*=footer],[id*=footer],[class*=header],[id*=header]';
 function collect(filter){
   var out=[],seen={};
   document.querySelectorAll('a[href]').forEach(function(a){
     try{
       var x=new URL(a.getAttribute('href'),base);
       if(x.hostname.replace(/^www\./,'')!==lh) return;
       if(x.pathname!==loc.pathname) return;
       if(!x.search || x.search===loc.search) return;
       if(filter && a.closest(skip)) return;
       var u=loc.origin+x.pathname+x.search;
       if(seen[u]) return; seen[u]=1;
       var t=(a.textContent||'').trim().replace(/\s+/g,' ');
       out.push([u,t]);
     }catch(e){}
   });
   return out;
 }
 var r=collect(true); if(r.length<2) r=collect(false);
 return JSON.stringify(r);
})()
"""

    private fun fetchCandidates() {
        view.evaluateJavascript(candJs) { res ->
            val list = ArrayList<Pair<String, String>>()
            try {
                val v = JSONTokener(res ?: "null").nextValue()
                if (v is String) {
                    val a = JSONArray(v)
                    for (i in 0 until a.length()) {
                        val r = a.getJSONArray(i)
                        list.add(Pair(r.getString(0), r.getString(1)))
                    }
                }
            } catch (e: Exception) { }
            if (list.size >= 2) showPicker(list) else showDiagnostics()
        }
    }

    private fun showPicker(cands: List<Pair<String, String>>) {
        val labels = cands.map { if (it.second.isNotEmpty()) it.second else folderName(it.first) }
        val lv = ListView(act)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = ArrayAdapter(act, android.R.layout.simple_list_item_multiple_choice, labels)
        val dlg = AlertDialog.Builder(act)
            .setTitle("Folders therndhedunga (${cands.size})")
            .setView(lv)
            .setPositiveButton("Download", null)
            .setNeutralButton("Select all", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        var allOn = false
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { b ->
            allOn = !allOn
            for (i in cands.indices) lv.setItemChecked(i, allOn)
            (b as Button).text = if (allOn) "Clear" else "Select all"
        }
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val picked = ArrayList<String>()
            for (i in cands.indices) if (lv.isItemChecked(i)) picked.add(cands[i].first)
            if (picked.isEmpty()) {
                toast("Edhaavadhu therndhedunga")
            } else {
                dlg.dismiss()
                startCrawl(rootLink, picked)
            }
        }
    }

    private fun showDiagnostics() {
        val tv = TextView(act).apply {
            setPadding(40, 20, 40, 20)
            setTextIsSelectable(true)
            text = "Media files edhuvum kidaikala.\n\n" +
                "Pages padichathu: ${rep.pages}\n" +
                "Links kidaichathu: ${rep.links}\n" +
                (rep.error?.let { "Error: $it\n" } ?: "") +
                "\nKadaisi page-oda links:\n" + rep.last.joinToString("\n") +
                "\n\nURL: $rootLink"
        }
        AlertDialog.Builder(act).setTitle("Result").setView(ScrollView(act).apply { addView(tv) })
            .setPositiveButton("OK", null).show()
    }

    private fun showResult() {
        val files = LinkedHashMap(found)
        if (files.isEmpty()) {
            if (!multi && !stopping) fetchCandidates() else showDiagnostics()
            return
        }
        val todo = files.keys.filter { !store.isDone(it) }
        val skipped = files.size - todo.size
        if (todo.isEmpty()) { toast("${files.size} files-um munnadiye download aagiduchu"); return }
        AlertDialog.Builder(act)
            .setTitle("${todo.size} files kidaichuduchu")
            .setMessage("Download aarambikkava?\n(Downloads/$appFolder la save aagum)" +
                (if (skipped > 0) "\n\n$skipped files munnadiye download aanadhu - skip pannum." else ""))
            .setPositiveButton("Download") { _, _ ->
                enqueue(todo.map { Dl(it, files[it] ?: "", refs[it] ?: rootLink) })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =====================================================================
    //  DOWNLOAD
    // =====================================================================
    private fun enqueue(list: List<Dl>) {
        if (list.isEmpty()) return
        if (dlRunning) {
            dlQueue.addAll(list); dlTotal += list.size
            toast("${list.size} file queue-la serthachu")
            pump()
            return
        }
        dlQueue.clear(); dlQueue.addAll(list)
        dlTotal = list.size; dlOk = 0; dlFail = 0; dlErrors.clear()
        dlPage = ""; loadingPage = false; dlPaused = false
        dlRunning = true
        act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startKeepAlive()
        showDownloads()
        handler.postDelayed(ticker, 1000)
        pump()
    }

    private fun refreshUi() {
        notifyProgress(true, if (dlPaused) "ABH download (paused)" else "ABH download",
            "${dlOk + dlFail} / $dlTotal  •  OK $dlOk, Fail $dlFail")
        refreshPage()
    }

    private fun notifyProgress(ongoing: Boolean, title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(act, 0,
                Intent(act, MainActivity::class.java)
                    .putExtra("open_downloads", true)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(act, channelId)
                    else Notification.Builder(act)
            b.setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download
                           else android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
            if (ongoing) b.setProgress(dlTotal, dlOk + dlFail, false) else b.setAutoCancel(true)
            nm.notify(MainActivity.NOTIF_ID, b.build())
        } catch (e: Exception) { }
    }

    // Foreground service: app background-la ponaalum process uyirodu irukka
    private fun startKeepAlive() {
        try {
            val i = Intent(act, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
        } catch (e: Exception) { }
    }

    private fun stopKeepAlive() {
        try { act.stopService(Intent(act, DownloadService::class.java)) } catch (e: Exception) { }
    }

    private fun stopDownloads() {
        if (!dlRunning) return
        dlQueue.clear()
        for (sq in slots.keys.toList()) finishFile(sq, "Stopped")
        if (slots.isEmpty()) finishDownloads()
    }

    private fun pump() {
        if (!dlRunning || loadingPage) return
        if (dlPaused) { refreshPage(); return }
        while (slots.size < store.dlConcurrency && dlQueue.isNotEmpty() && dlQueue[0].page == dlPage) {
            startFetch(dlQueue.removeAt(0))
        }
        if (slots.isEmpty()) {
            if (dlQueue.isEmpty()) { finishDownloads(); return }
            // Adutha folder page-a browser-la thirandha maathiri (session/cookie set aagum)
            dlPage = dlQueue[0].page
            loadingPage = true
            crawlHost = hostOf(dlPage)
            val tk = ++dlToken
            view.loadUrl(dlPage)
            handler.postDelayed({
                if (dlRunning && tk == dlToken && loadingPage) { loadingPage = false; pump() }
            }, 30000)
        }
    }

    private fun onDlPageLoaded() {
        if (!loadingPage) return
        val tk = dlToken
        handler.postDelayed({
            if (dlRunning && tk == dlToken && loadingPage) { loadingPage = false; pump() }
        }, 600)
    }

    private fun startFetch(d: Dl) {
        val seq = ++seqGen
        val s = Slot(seq, d)
        s.name = fileName(d.url)
        s.lastAct = System.currentTimeMillis()
        slots[seq] = s
        val os = try { openOut(s, d.rel, s.name) } catch (e: Exception) { null }
        if (os == null) { finishFile(seq, "File create panna mudiyala"); return }
        s.out = os
        val sameHost = hostOf(d.url) == hostOf(d.page)
        if (sameHost) {
            val script = fetchJs.replace("__URL__", JSONObject.quote(d.url)).replace("__SEQ__", seq.toString())
            view.evaluateJavascript(script, null)
        } else {
            downloadDirect(s, view.settings.userAgentString, CookieManager.getInstance().getCookie(d.url))
        }
    }

    // Vera host-la irukkura files-ku
    private fun downloadDirect(s: Slot, ua: String, cookie: String?) {
        Thread {
            var err: String? = null
            try {
                val c = URL(s.dl.url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 30000
                c.setRequestProperty("User-Agent", ua)
                c.setRequestProperty("Referer", s.dl.page)
                if (cookie != null) c.setRequestProperty("Cookie", cookie)
                if (c.responseCode !in 200..299) {
                    err = "HTTP ${c.responseCode}"
                } else {
                    c.inputStream.use { ins ->
                        val buf = ByteArray(65536)
                        while (slots.containsKey(s.seq)) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            s.out?.write(buf, 0, n)
                            s.bytes += n
                            s.lastAct = System.currentTimeMillis()
                        }
                    }
                }
            } catch (e: Exception) { err = e.toString() }
            val e2 = err
            handler.post { finishFile(s.seq, e2) }
        }.start()
    }

    private fun openOut(s: Slot, rel: String, name: String): OutputStream? {
        val relDir = rel.trimEnd('/')
        if (Build.VERSION.SDK_INT >= 29) {
            val path = "Download/$appFolder/" + (if (relDir.isEmpty()) "" else "$relDir/")
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
                put(MediaStore.MediaColumns.RELATIVE_PATH, path)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            s.uri = uri
            return act.contentResolver.openOutputStream(uri)
        } else {
            val base = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), appFolder)
            val dir = if (relDir.isEmpty()) base else File(base, relDir)
            dir.mkdirs()
            val f = File(dir, name)
            s.file = f
            return FileOutputStream(f)
        }
    }

    private fun finishFile(seq: Int, err: String?) {
        val s = slots.remove(seq) ?: return
        try { s.out?.flush(); s.out?.close() } catch (e: Exception) { }
        s.out = null
        val problem = err ?: s.ioErr ?: (if (s.bytes == 0L) "File empty" else null)
        val now = System.currentTimeMillis()
        if (problem != null) {
            // JS fetch-a nirutha
            view.evaluateJavascript("(window.__abhX=window.__abhX||{})[$seq]=1;", null)
            try {
                s.uri?.let { act.contentResolver.delete(it, null, null) }
                s.file?.delete()
            } catch (e: Exception) { }
            if (err != "Stopped") {
                dlFail++
                dlErrors.add("${s.name}: $problem")
                store.addDownload(Store.DlItem(s.name, s.dl.rel, "", false, now, s.dl.page))
            }
        } else {
            try {
                s.uri?.let {
                    act.contentResolver.update(it, ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                    }, null, null)
                }
                s.file?.let { MediaScannerConnection.scanFile(act, arrayOf(it.absolutePath), null, null) }
            } catch (e: Exception) { }
            dlOk++
            store.markDone(s.dl.url)
            store.addDownload(Store.DlItem(s.name, s.dl.rel, s.uri?.toString() ?: "", true, now, s.dl.page))
        }
        refreshPage()
        handler.post { pump() }
    }

    private fun finishDownloads() {
        if (!dlRunning) return
        dlRunning = false
        dlPaused = false
        loadingPage = false
        dlToken++
        handler.removeCallbacks(ticker)
        act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        stopKeepAlive()
        notifyProgress(false, "ABH download mudinjuduchu", "OK $dlOk, Fail $dlFail  •  Downloads/$appFolder")
        if (pageDlg != null) {
            pLastKey = ""
            refreshPage()
            toast("Download mudinjuduchu: OK $dlOk, Fail $dlFail")
        } else {
            val tv = TextView(act).apply {
                setPadding(48, 24, 48, 24); setTextIsSelectable(true)
                text = "Mudinjathu: $dlOk\nFail: $dlFail\n\nSave aana idam:\nDownloads/$appFolder/" +
                    (if (dlErrors.isNotEmpty()) "\n\nErrors:\n" + dlErrors.take(6).joinToString("\n") else "")
            }
            AlertDialog.Builder(act).setTitle("Download mudinjuduchu")
                .setView(ScrollView(act).apply { addView(tv) })
                .setPositiveButton("OK", null).show()
        }
    }
}
