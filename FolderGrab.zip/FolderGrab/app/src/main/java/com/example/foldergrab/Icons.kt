package com.example.foldergrab

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** Chinna vector icons (back, home, reload, star, download...) - theme colour-la varum. */
class IconView(ctx: Context, private val kind: Int, var tint: Int) : View(ctx) {

    companion object {
        const val BACK = 0
        const val FORWARD = 1
        const val HOME = 2
        const val PLUS = 3
        const val RELOAD = 4
        const val STAR = 5
        const val DOWNLOAD = 6
        const val DOTS = 7
        const val TABS = 8
    }

    var filled = false
    var label = ""

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f
        p.color = tint
        p.strokeWidth = s * 0.09f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        path.reset()

        when (kind) {
            BACK -> {
                c.drawLine(cx + s * 0.35f, cy, cx - s * 0.35f, cy, p)
                path.moveTo(cx - s * 0.05f, cy - s * 0.3f)
                path.lineTo(cx - s * 0.35f, cy)
                path.lineTo(cx - s * 0.05f, cy + s * 0.3f)
                c.drawPath(path, p)
            }
            FORWARD -> {
                c.drawLine(cx - s * 0.35f, cy, cx + s * 0.35f, cy, p)
                path.moveTo(cx + s * 0.05f, cy - s * 0.3f)
                path.lineTo(cx + s * 0.35f, cy)
                path.lineTo(cx + s * 0.05f, cy + s * 0.3f)
                c.drawPath(path, p)
            }
            HOME -> {
                p.style = Paint.Style.FILL
                path.moveTo(cx - s * 0.46f, cy - s * 0.02f)
                path.lineTo(cx, cy - s * 0.44f)
                path.lineTo(cx + s * 0.46f, cy - s * 0.02f)
                path.lineTo(cx + s * 0.32f, cy - s * 0.02f)
                path.lineTo(cx + s * 0.32f, cy + s * 0.4f)
                path.lineTo(cx + s * 0.08f, cy + s * 0.4f)
                path.lineTo(cx + s * 0.08f, cy + s * 0.1f)
                path.lineTo(cx - s * 0.08f, cy + s * 0.1f)
                path.lineTo(cx - s * 0.08f, cy + s * 0.4f)
                path.lineTo(cx - s * 0.32f, cy + s * 0.4f)
                path.lineTo(cx - s * 0.32f, cy - s * 0.02f)
                path.close()
                c.drawPath(path, p)
            }
            PLUS -> {
                c.drawLine(cx - s * 0.38f, cy, cx + s * 0.38f, cy, p)
                c.drawLine(cx, cy - s * 0.38f, cx, cy + s * 0.38f, p)
            }
            RELOAD -> {
                val r = s * 0.36f
                rect.set(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(rect, -60f, 300f, false, p)
                // arrow head at the end of the arc (240 degrees)
                val ex = cx - r * 0.5f
                val ey = cy - r * 0.866f
                p.style = Paint.Style.FILL
                path.moveTo(ex + 0.866f * s * 0.17f, ey - 0.5f * s * 0.17f)
                path.lineTo(ex + 0.5f * s * 0.14f, ey + 0.866f * s * 0.14f)
                path.lineTo(ex - 0.5f * s * 0.14f, ey - 0.866f * s * 0.14f)
                path.close()
                c.drawPath(path, p)
            }
            STAR -> {
                val outer = s * 0.46f
                val inner = s * 0.2f
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) outer else inner
                    val a = Math.toRadians((-90 + i * 36).toDouble())
                    val x = cx + (r * Math.cos(a)).toFloat()
                    val y = cy + (r * Math.sin(a)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                p.style = if (filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
                c.drawPath(path, p)
            }
            DOWNLOAD -> {
                c.drawLine(cx, cy - s * 0.38f, cx, cy + s * 0.18f, p)
                path.moveTo(cx - s * 0.24f, cy - s * 0.06f)
                path.lineTo(cx, cy + s * 0.18f)
                path.lineTo(cx + s * 0.24f, cy - s * 0.06f)
                c.drawPath(path, p)
                c.drawLine(cx - s * 0.38f, cy + s * 0.38f, cx + s * 0.38f, cy + s * 0.38f, p)
            }
            DOTS -> {
                p.style = Paint.Style.FILL
                val r = s * 0.07f
                c.drawCircle(cx, cy - s * 0.3f, r, p)
                c.drawCircle(cx, cy, r, p)
                c.drawCircle(cx, cy + s * 0.3f, r, p)
            }
            TABS -> {
                rect.set(cx - s * 0.4f, cy - s * 0.4f, cx + s * 0.4f, cy + s * 0.4f)
                c.drawRoundRect(rect, s * 0.14f, s * 0.14f, p)
                if (label.isNotEmpty()) {
                    p.style = Paint.Style.FILL
                    p.textAlign = Paint.Align.CENTER
                    p.typeface = Typeface.DEFAULT_BOLD
                    p.textSize = s * 0.42f
                    c.drawText(label, cx, cy - (p.descent() + p.ascent()) / 2f, p)
                }
            }
        }
    }
}
