package com.example.foldergrab

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

// Download nadakkum bodhu app-a background-la uyirodu vaikka (notification kaattum)
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(MainActivity.CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, MainActivity.CHANNEL)
        } else {
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("ABH")
            .setContentText("Download aagudhu...")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
        startForeground(MainActivity.NOTIF_ID, n)
        return START_NOT_STICKY
    }
}
