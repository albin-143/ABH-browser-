package com.example.foldergrab

import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Settings, bookmarks, history, download log - ellam phone-la save aagum. */
class Palette(val dark: Boolean) {
    val bg = if (dark) 0xFF121214.toInt() else 0xFFFFFFFF.toInt()
    val bar = if (dark) 0xFF0F0F13.toInt() else 0xFFF3F3F3.toInt()
    val field = if (dark) 0xFF4A4A52.toInt() else 0xFFE8E8EB.toInt()
    val tile = if (dark) 0xFF232428.toInt() else 0xFFF1F3F4.toInt()
    val menu = if (dark) 0xFF1F1F26.toInt() else 0xFFFFFFFF.toInt()
    val text = if (dark) 0xFFE6E6EA.toInt() else 0xFF202124.toInt()
    val sub = if (dark) 0xFF9A9AA2.toInt() else 0xFF777777.toInt()
    val stroke = if (dark) 0xFF8A8A90.toInt() else 0xFFBDBDBD.toInt()
}

class Store(private val ctx: Context) {

    class Item(val title: String, val url: String)
    class DlItem(val name: String, val rel: String, val uri: String, val ok: Boolean, val time: Long, val page: String = "")

    private val sp = ctx.getSharedPreferences("abh", Context.MODE_PRIVATE)

    val engineNames = listOf("Google", "DuckDuckGo", "Bing")

    var searchEngine: Int
        get() = sp.getInt("engine", 0)
        set(v) { sp.edit().putInt("engine", v).apply() }

    var desktopDefault: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) { sp.edit().putBoolean("desktop", v).apply() }

    var dlConcurrency: Int
        get() = sp.getInt("conc", 4)
        set(v) { sp.edit().putInt("conc", v).apply() }

    // 0 = Auto, 1 = Day, 2 = Night
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    fun palette(): Palette {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return Palette(theme == 2 || (theme == 0 && night))
    }

    // theme maathumbothu tabs-a thirumba kondu vara
    var savedTabs: String
        get() = sp.getString("savedTabs", "") ?: ""
        set(v) { sp.edit().putString("savedTabs", v).apply() }
    var savedCur: Int
        get() = sp.getInt("savedCur", 0)
        set(v) { sp.edit().putInt("savedCur", v).apply() }
    var restoreFlag: Boolean
        get() = sp.getBoolean("restoreFlag", false)
        set(v) { sp.edit().putBoolean("restoreFlag", v).apply() }

    fun searchUrl(q: String): String {
        val base = when (searchEngine) {
            1 -> "https://duckduckgo.com/?q="
            2 -> "https://www.bing.com/search?q="
            else -> "https://www.google.com/search?q="
        }
        return base + Uri.encode(q)
    }

    // ---------- bookmarks & history ----------
    private fun readItems(key: String): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val a = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Item(o.getString("t"), o.getString("u")))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun writeItems(key: String, list: List<Item>) {
        val a = JSONArray()
        for (x in list) a.put(JSONObject().put("t", x.title).put("u", x.url))
        sp.edit().putString(key, a.toString()).apply()
    }

    fun bookmarks(): List<Item> = readItems("bm")
    fun isBookmarked(url: String): Boolean = readItems("bm").any { it.url == url }

    fun addBookmark(title: String, url: String) {
        val l = readItems("bm")
        if (l.none { it.url == url }) {
            l.add(0, Item(title, url))
            writeItems("bm", l)
        }
    }

    fun removeBookmark(url: String) {
        val l = readItems("bm")
        l.removeAll { it.url == url }
        writeItems("bm", l)
    }

    fun history(): List<Item> = readItems("hist")

    fun addHistory(title: String, url: String) {
        val l = readItems("hist")
        l.removeAll { it.url == url }
        l.add(0, Item(title, url))
        while (l.size > 500) l.removeAt(l.size - 1)
        writeItems("hist", l)
    }

    fun clearHistory() { sp.edit().remove("hist").apply() }

    // ---------- download log (last 300) ----------
    fun downloads(): List<DlItem> {
        val out = ArrayList<DlItem>()
        try {
            val a = JSONArray(sp.getString("dl", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(DlItem(o.getString("n"), o.getString("r"), o.getString("u"),
                    o.getBoolean("k"), o.getLong("t"), o.optString("p", "")))
            }
        } catch (e: Exception) { }
        return out
    }

    fun addDownload(d: DlItem) {
        val old = downloads()
        val a = JSONArray()
        a.put(toJson(d))
        for (i in 0 until minOf(old.size, 299)) a.put(toJson(old[i]))
        sp.edit().putString("dl", a.toString()).apply()
    }

    private fun toJson(d: DlItem) = JSONObject()
        .put("n", d.name).put("r", d.rel).put("u", d.uri).put("k", d.ok).put("t", d.time).put("p", d.page)

    fun removeDownload(x: DlItem) {
        val a = JSONArray()
        for (d in downloads()) if (!(d.time == x.time && d.name == x.name)) a.put(toJson(d))
        sp.edit().putString("dl", a.toString()).apply()
    }

    fun clearDownloadsLog() { sp.edit().remove("dl").apply() }

    // ---------- already downloaded URLs (resume / skip) ----------
    private val doneFile = File(ctx.filesDir, "done.txt")
    private val done: HashSet<String> by lazy {
        val s = HashSet<String>()
        try { if (doneFile.exists()) doneFile.forEachLine { s.add(it) } } catch (e: Exception) { }
        s
    }

    fun isDone(url: String): Boolean = done.contains(url)

    fun markDone(url: String) {
        if (done.add(url)) {
            try { doneFile.appendText(url + "\n") } catch (e: Exception) { }
        }
    }

    fun clearDone() {
        done.clear()
        try { doneFile.delete() } catch (e: Exception) { }
    }
}
