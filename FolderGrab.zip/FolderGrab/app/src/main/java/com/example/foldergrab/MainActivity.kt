package com.example.foldergrab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import java.net.URL
import java.net.URLDecoder

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var urlBar: EditText

    // Download panna vendiya file types. Venumna maathikalam.
    private val exts = setOf("mp3", "m4a", "wav", "flac", "aac", "ogg",
        "mp4", "mkv", "webm", "avi", "mov", "3gp")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT in 23..28) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }

        urlBar = EditText(this).apply {
            hint = "Website URL paste pannunga"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> load(text.toString()); true }
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) { urlBar.setText(url) }
            }
            // LONG PRESS: link mela pidichaa folder full download
            setOnLongClickListener {
                val r = hitTestResult
                val link = r.extra
                if (r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE && link != null) {
                    confirmAndGrab(link); true
                } else false
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(urlBar, LinearLayout.LayoutParams(-1, -2))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    private fun load(input: String) {
        var u = input.trim()
        if (!u.startsWith("http")) u = "http://$u"
        web.loadUrl(u)
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    private fun confirmAndGrab(link: String) {
        AlertDialog.Builder(this)
            .setTitle("Download all?")
            .setMessage("$link\n\nIntha folder la (subfolders ulla) ella mp3/video-um download aagum.")
            .setPositiveButton("Download") { _, _ -> grab(link) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun ext(u: String) = u.substringBefore('?').substringAfterLast('.', "").lowercase()

    private fun grab(link: String) {
        toast("Files-a thedureen...")
        Thread {
            try {
                val found = ArrayList<Pair<String, String>>() // url to relative path
                if (ext(link) in exts) {
                    found.add(link to "")
                } else {
                    val dir = if (link.endsWith("/")) link else "$link/"
                    val folderName = decode(dir.trimEnd('/').substringAfterLast('/'))
                    crawl(dir, "$folderName/", 0, found, HashSet())
                }
                if (found.isEmpty()) { toast("Media files edhuvum kidaikala"); return@Thread }
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                for ((url, rel) in found) {
                    val name = decode(url.substringBefore('?').substringAfterLast('/'))
                    val path = "FolderGrab/" + rel + name
                    dm.enqueue(
                        DownloadManager.Request(Uri.parse(url))
                            .setTitle(name)
                            .setNotificationVisibility(
                                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, path)
                    )
                }
                toast("${found.size} files download aaga aarambichuduchu (Downloads/FolderGrab)")
            } catch (e: Exception) {
                toast("Error: ${e.message}")
            }
        }.start()
    }

    private fun crawl(dir: String, rel: String, depth: Int,
                      out: MutableList<Pair<String, String>>, seen: MutableSet<String>) {
        if (depth > 8 || !seen.add(dir)) return
        val conn = URL(dir).openConnection().apply { connectTimeout = 15000; readTimeout = 15000 }
        val html = conn.getInputStream().bufferedReader().use { it.readText() }
        val base = URL(dir)
        val re = Regex("""href\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        for (m in re.findAll(html)) {
            val href = m.groupValues[1].trim()
            if (href.startsWith("?") || href.startsWith("#") || href.startsWith("javascript")) continue
            val full = try { URL(base, href).toString().substringBefore('#') } catch (e: Exception) { continue }
            // "../" (parent) skip: dir kulla irukkura links mattum
            if (!full.startsWith(dir) || full == dir || full.contains('?')) continue
            if (full.endsWith("/")) {
                val sub = decode(full.trimEnd('/').substringAfterLast('/'))
                crawl(full, "$rel$sub/", depth + 1, out, seen)
            } else if (ext(full) in exts) {
                out.add(full to rel)
            }
        }
    }

    private fun decode(s: String) = try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }
        .replace(Regex("""[\\:*?"<>|]"""), "_")
}
