package com.example.foldergrab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var crawler: WebView   // maraivaana browser: pages padikkavum, download pannavum
    private lateinit var urlBar: EditText
    private val handler = Handler(Looper.getMainLooper())

    private val appFolder = "ABH browser"   // Downloads/ABH browser/...

    private val exts = setOf("mp3", "m4a", "wav", "flac", "aac", "ogg", "wma",
        "mp4", "mkv", "webm", "avi", "mov", "3gp")

    private class Job(val url: String, val rel: String, val depth: Int)
    private class Report {
        var pages = 0
        var links = 0
        var last: List<String> = emptyList()
        var error: String? = null
    }
    private class Dl(val url: String, val rel: String, val page: String)

    // ---- crawl state ----
    private val queue = ArrayList<Job>()
    private val seen = HashSet<String>()
    private val found = LinkedHashMap<String, String>() // url -> relative folder
    private val refs = HashMap<String, String>()        // media url -> page url
    private var rep = Report()
    private var current: Job? = null
    private var running = false
    private var loadToken = 0
    private var scheduledToken = -1
    private var rootLink = ""
    private var progress: AlertDialog? = null
    private var progressText: TextView? = null

    // ---- download state ----
    private val dlQueue = ArrayList<Dl>()
    private var dlRunning = false
    private var dlTotal = 0
    private var dlOk = 0
    private var dlFail = 0
    private val dlErrors = ArrayList<String>()
    private var dlCur: Dl? = null
    private var dlPage = ""
    private var dlWaitingPage = false
    private var dlToken = 0
    private var dlDialog: AlertDialog? = null
    private var dlText: TextView? = null
    @Volatile private var curSeq = 0
    @Volatile private var fetching = false
    @Volatile private var out: OutputStream? = null
    @Volatile private var ioErr: String? = null
    @Volatile private var bytes = 0L
    @Volatile private var lastAct = 0L
    private var outUri: Uri? = null
    private var outFile: File? = null

    private val js = """
(function(){
 var L=[],M={};
 document.querySelectorAll('a[href],[src],source,audio,video,[data-src],[data-url]').forEach(function(e){
   ['href','src','data-src','data-url'].forEach(function(a){
     var v=e.getAttribute(a);
     if(v){ try{ L.push(new URL(v,document.baseURI).href); }catch(x){} }
   });
 });
 var h=document.documentElement.outerHTML;
 var re=/["'(]([^"'()\s<>]+\.(?:mp3|m4a|wav|flac|aac|ogg|wma|mp4|mkv|webm|avi|mov|3gp)(?:\?[^"'()\s<>]*)?)["')]/gi, m;
 while((m=re.exec(h))){ try{ M[new URL(m[1].replace(/&amp;/g,'&'),document.baseURI).href]=1; }catch(x){} }
 return JSON.stringify({u:location.href,l:L,m:Object.keys(M)});
})()
"""

    // Browser kulla irundhu file-a stream panni app-ku anuppum
    private val fetchJs = """
(async function(url,seq){
 try{
  var r=await fetch(url,{credentials:'include'});
  if(!r.ok){ABH.fail(seq,'HTTP '+r.status);return;}
  var rd=r.body.getReader(),total=0;
  while(true){
   var x=await rd.read();
   if(x.done)break;
   var v=x.value,bin='';
   for(var i=0;i<v.length;i+=32768){bin+=String.fromCharCode.apply(null,v.subarray(i,i+32768));}
   ABH.chunk(seq,btoa(bin)); total+=v.length;
  }
  ABH.done(seq,''+total);
 }catch(e){ABH.fail(seq,''+e);}
})(__URL__,__SEQ__);
"""

    inner class Bridge {
        @JavascriptInterface
        fun chunk(seq: Int, b64: String) {
            if (seq != curSeq || !dlRunning) return
            try {
                val data = Base64.decode(b64, Base64.DEFAULT)
                out?.write(data)
                bytes += data.size
                lastAct = System.currentTimeMillis()
            } catch (e: Exception) { ioErr = e.toString() }
        }
        @JavascriptInterface
        fun done(seq: Int, total: String) { handler.post { finishFile(seq, null) } }
        @JavascriptInterface
        fun fail(seq: Int, msg: String) { handler.post { finishFile(seq, msg) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT in 23..28) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        urlBar = EditText(this).apply {
            hint = "Website URL paste pannunga"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> load(text.toString()); true }
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) { urlBar.setText(url) }
            }
            setOnLongClickListener {
                val r = hitTestResult
                val extra = r.extra
                when (r.type) {
                    WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                        if (extra != null) { confirmAndGrab(extra); true } else false
                    }
                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                        val msg = Handler(mainLooper) { m ->
                            val u = m.data.getString("url")
                            if (u != null) confirmAndGrab(u)
                            true
                        }.obtainMessage()
                        requestFocusNodeHref(msg)
                        true
                    }
                    else -> false
                }
            }
        }
        crawler = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "ABH")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) { onCrawlLoaded() }
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(urlBar, LinearLayout.LayoutParams(-1, -2))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(crawler, LinearLayout.LayoutParams(1, 1))
        })
        handler.post(watchdog)
    }

    private fun load(input: String) {
        var u = input.trim()
        if (!u.startsWith("http")) u = "http://$u"
        web.loadUrl(u)
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- helpers ----------
    private fun pathOf(u: String) = try { URL(u).path ?: "" } catch (e: Exception) { "" }
    private fun extOf(s: String) = s.substringBefore('?').substringAfterLast('.', "").lowercase()

    private fun isMedia(u: String): Boolean {
        if (extOf(pathOf(u)) in exts) return true
        return try {
            val uri = Uri.parse(u)
            uri.queryParameterNames.any { extOf(uri.getQueryParameter(it) ?: "") in exts }
        } catch (e: Exception) { false }
    }

    private fun fileName(u: String): String {
        val p = pathOf(u).substringAfterLast('/')
        if (extOf(p) in exts) return decode(p)
        try {
            val uri = Uri.parse(u)
            for (n in uri.queryParameterNames) {
                val v = uri.getQueryParameter(n) ?: continue
                if (extOf(v) in exts) return decode(v.substringAfterLast('/'))
            }
        } catch (e: Exception) { }
        return decode(p).ifEmpty { "file" }
    }

    private fun folderName(u: String): String {
        val f = try { Uri.parse(u).getQueryParameter("folder") } catch (e: Exception) { null }
        val raw = f ?: pathOf(u)
        return decode(raw.trimEnd('/').substringAfterLast('/')).ifEmpty { "folder" }
    }

    private fun isSubfolder(cur: String, c: String): Boolean {
        val cu = try { URL(cur) } catch (e: Exception) { return false }
        val cc = try { URL(c) } catch (e: Exception) { return false }
        if (cu.host != cc.host) return false
        val cf = Uri.parse(cur).getQueryParameter("folder")
        val nf = Uri.parse(c).getQueryParameter("folder")
        if (nf != null && cf != null) {
            return cu.path == cc.path && nf.startsWith(cf.trimEnd('/') + "/") && nf != cf
        }
        val dirPrefix = cu.path.trimEnd('/') + "/"
        val last = cc.path.trimEnd('/').substringAfterLast('/')
        return cc.path.startsWith(dirPrefix) && cc.path != dirPrefix &&
            (cc.path.endsWith("/") || !last.contains('.'))
    }

    private fun decode(s: String) =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }
            .replace(Regex("""[\\:*?"<>|]"""), "_")

    private fun mimeOf(name: String) = when (extOf(name)) {
        "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "wav" -> "audio/x-wav"
        "flac" -> "audio/flac"; "aac" -> "audio/aac"; "ogg" -> "audio/ogg"; "wma" -> "audio/x-ms-wma"
        "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"
        "avi" -> "video/x-msvideo"; "mov" -> "video/quicktime"; "3gp" -> "video/3gpp"
        else -> "application/octet-stream"
    }

    // ---------- long press flow ----------
    private fun confirmAndGrab(link: String) {
        if (running || dlRunning) { toast("Munnaadi aarambicha vela innum odikittu irukku"); return }
        AlertDialog.Builder(this)
            .setTitle("Files-a thedava?")
            .setMessage("$link\n\nIntha folder (subfolders ulla) la ulla media files-a thedi count kaattuven.")
            .setPositiveButton("Thedu") { _, _ -> startCrawl(link) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startCrawl(link: String) {
        found.clear(); seen.clear(); queue.clear(); refs.clear(); rep = Report()
        rootLink = link
        if (isMedia(link)) {
            found[link] = ""
            refs[link] = web.url ?: link
            showResult(link, LinkedHashMap(found), rep)
            return
        }
        running = true
        queue.add(Job(link, folderName(link) + "/", 0))
        progressText = TextView(this).apply { setPadding(48, 32, 48, 16); text = "Thedureen..." }
        progress = AlertDialog.Builder(this)
            .setTitle("Files-a thedureen")
            .setView(progressText)
            .setCancelable(false)
            .setNegativeButton("Stop") { _, _ -> if (running) finishCrawl() }
            .show()
        next()
    }

    private fun next() {
        if (!running) return
        var job: Job? = null
        while (queue.isNotEmpty()) {
            val j = queue.removeAt(0)
            if (j.depth <= 8 && seen.add(j.url)) { job = j; break }
        }
        if (job == null) { finishCrawl(); return }
        current = job
        val t = ++loadToken
        progressText?.text = "Pages: ${rep.pages}   Files: ${found.size}\n\n${job.rel}"
        crawler.loadUrl(job.url)
        handler.postDelayed({
            if (running && t == loadToken) { scheduledToken = t; extract(t) }
        }, 30000)
    }

    private fun onCrawlLoaded() {
        if (dlRunning) { onDlPageLoaded(); return }
        if (!running || current == null) return
        val t = loadToken
        if (scheduledToken == t) return
        scheduledToken = t
        handler.postDelayed({ extract(t) }, 800)
    }

    private fun extract(t: Int) {
        if (!running || t != loadToken) return
        crawler.evaluateJavascript(js) { res -> onExtracted(t, res) }
    }

    private fun onExtracted(t: Int, res: String?) {
        if (!running || t != loadToken) return
        loadToken++
        val job = current ?: return
        try {
            val s = JSONTokener(res ?: "null").nextValue()
            if (s is String) handlePage(job, JSONObject(s)) else rep.error = "Page data kidaikala"
        } catch (e: Exception) {
            rep.error = e.toString()
        }
        handler.post { next() }
    }

    private fun handlePage(job: Job, o: JSONObject) {
        val pageUrl = o.optString("u", job.url)
        val links = o.getJSONArray("l")
        val media = o.getJSONArray("m")
        rep.pages++
        val uniq = LinkedHashSet<String>()
        for (i in 0 until links.length()) uniq.add(links.getString(i).substringBefore('#'))
        rep.links += uniq.size
        rep.last = uniq.toList().takeLast(15)
        for (i in 0 until media.length()) {
            val m = media.getString(i)
            if (!found.containsKey(m)) { found[m] = job.rel; refs[m] = pageUrl }
        }
        for (l in uniq) {
            if (isMedia(l)) {
                if (!found.containsKey(l)) { found[l] = job.rel; refs[l] = pageUrl }
            } else if (isSubfolder(pageUrl, l)) {
                queue.add(Job(l, job.rel + folderName(l) + "/", job.depth + 1))
            }
        }
    }

    private fun finishCrawl() {
        running = false
        current = null
        loadToken++
        handler.removeCallbacksAndMessages(null)
        handler.post(watchdog)
        progress?.dismiss(); progress = null
        showResult(rootLink, LinkedHashMap(found), rep)
    }

    private fun showResult(link: String, files: Map<String, String>, r: Report) {
        if (files.isEmpty()) {
            val tv = TextView(this).apply {
                setPadding(40, 20, 40, 20)
                setTextIsSelectable(true)
                text = "Media files edhuvum kidaikala.\n\n" +
                    "Pages padichathu: ${r.pages}\n" +
                    "Links kidaichathu: ${r.links}\n" +
                    (r.error?.let { "Error: $it\n" } ?: "") +
                    "\nKadaisi page-oda links:\n" + r.last.joinToString("\n") +
                    "\n\nURL: $link"
            }
            AlertDialog.Builder(this).setTitle("Result").setView(ScrollView(this).apply { addView(tv) })
                .setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("${files.size} files kidaichuduchu")
            .setMessage("Download aarambikkava?\n(Downloads/$appFolder la save aagum)")
            .setPositiveButton("Download") { _, _ -> startDownloads(link, files) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- in-app downloader ----------
    private fun startDownloads(fallbackPage: String, files: Map<String, String>) {
        dlQueue.clear(); dlErrors.clear()
        for ((url, rel) in files) dlQueue.add(Dl(url, rel, refs[url] ?: fallbackPage))
        dlTotal = dlQueue.size; dlOk = 0; dlFail = 0
        dlPage = ""; dlRunning = true; dlCur = null
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        dlText = TextView(this).apply { setPadding(48, 32, 48, 16); text = "Aarambikkuthu..." }
        dlDialog = AlertDialog.Builder(this)
            .setTitle("Download aagudhu")
            .setView(dlText)
            .setCancelable(false)
            .setNegativeButton("Stop") { _, _ -> stopDownloads() }
            .show()
        downloadNext()
    }

    private fun stopDownloads() {
        if (!dlRunning) return
        dlQueue.clear()
        if (fetching) finishFile(curSeq, "Stopped") else finishDownloads()
    }

    private fun downloadNext() {
        if (!dlRunning) return
        if (dlQueue.isEmpty()) { finishDownloads(); return }
        val d = dlQueue.removeAt(0)
        dlCur = d
        dlText?.text = "${dlOk + dlFail + 1} / $dlTotal\n\n${d.rel}${fileName(d.url)}\n\nOK: $dlOk   Fail: $dlFail"
        if (d.page != dlPage) {
            // Browser-la antha page-a thirandha maathiri session/cookie set aagum
            dlPage = d.page
            dlWaitingPage = true
            val tk = ++dlToken
            crawler.loadUrl(d.page)
            handler.postDelayed({
                if (dlRunning && tk == dlToken && dlWaitingPage) { dlWaitingPage = false; startFetch(d) }
            }, 30000)
        } else {
            startFetch(d)
        }
    }

    private fun onDlPageLoaded() {
        if (!dlWaitingPage) return
        dlWaitingPage = false
        val d = dlCur ?: return
        val tk = dlToken
        handler.postDelayed({ if (dlRunning && tk == dlToken) startFetch(d) }, 600)
    }

    private fun startFetch(d: Dl) {
        if (!dlRunning) return
        curSeq++
        val seq = curSeq
        val name = fileName(d.url)
        val os = try { openOut(d.rel, name) } catch (e: Exception) { null }
        if (os == null) { fetching = true; finishFile(seq, "File create panna mudiyala"); return }
        out = os; ioErr = null; bytes = 0L; lastAct = System.currentTimeMillis(); fetching = true

        val sameHost = try { URL(d.url).host == URL(d.page).host } catch (e: Exception) { false }
        if (sameHost) {
            val script = fetchJs.replace("__URL__", JSONObject.quote(d.url)).replace("__SEQ__", seq.toString())
            crawler.evaluateJavascript(script, null)
        } else {
            downloadDirect(d, seq, crawler.settings.userAgentString,
                CookieManager.getInstance().getCookie(d.url))
        }
    }

    // Vera host-la irukkura files-ku
    private fun downloadDirect(d: Dl, seq: Int, ua: String, cookie: String?) {
        Thread {
            var err: String? = null
            try {
                val c = URL(d.url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 30000
                c.setRequestProperty("User-Agent", ua)
                c.setRequestProperty("Referer", d.page)
                if (cookie != null) c.setRequestProperty("Cookie", cookie)
                if (c.responseCode !in 200..299) {
                    err = "HTTP ${c.responseCode}"
                } else {
                    c.inputStream.use { ins ->
                        val buf = ByteArray(65536)
                        while (seq == curSeq) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out?.write(buf, 0, n)
                            bytes += n
                            lastAct = System.currentTimeMillis()
                        }
                    }
                }
            } catch (e: Exception) { err = e.toString() }
            val e2 = err
            handler.post { finishFile(seq, e2) }
        }.start()
    }

    private fun openOut(rel: String, name: String): OutputStream? {
        val relDir = rel.trimEnd('/')
        if (Build.VERSION.SDK_INT >= 29) {
            val path = "Download/$appFolder/" + (if (relDir.isEmpty()) "" else "$relDir/")
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
                put(MediaStore.MediaColumns.RELATIVE_PATH, path)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            outUri = uri; outFile = null
            return contentResolver.openOutputStream(uri)
        } else {
            val base = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), appFolder)
            val dir = if (relDir.isEmpty()) base else File(base, relDir)
            dir.mkdirs()
            val f = File(dir, name)
            outFile = f; outUri = null
            return FileOutputStream(f)
        }
    }

    private fun finishFile(seq: Int, err: String?) {
        if (seq != curSeq || !dlRunning || !fetching) return
        curSeq++          // late callbacks-a ignore panna
        fetching = false
        val d = dlCur
        try { out?.flush(); out?.close() } catch (e: Exception) { }
        out = null
        val problem = err ?: ioErr ?: (if (bytes == 0L) "File empty" else null)
        if (problem != null) {
            try {
                outUri?.let { contentResolver.delete(it, null, null) }
                outFile?.delete()
            } catch (e: Exception) { }
            if (err != "Stopped") {
                dlFail++
                dlErrors.add("${d?.let { fileName(it.url) } ?: "?"}: $problem")
            }
        } else {
            try {
                outUri?.let {
                    contentResolver.update(it, ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                    }, null, null)
                }
                outFile?.let { MediaScannerConnection.scanFile(this, arrayOf(it.absolutePath), null, null) }
            } catch (e: Exception) { }
            dlOk++
        }
        handler.post { downloadNext() }
    }

    private fun finishDownloads() {
        if (!dlRunning) return
        dlRunning = false
        dlCur = null
        dlToken++
        fetching = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        dlDialog?.dismiss(); dlDialog = null
        val tv = TextView(this).apply {
            setPadding(48, 24, 48, 24); setTextIsSelectable(true)
            text = "Mudinjathu: $dlOk\nFail: $dlFail\n\nSave aana idam:\nDownloads/$appFolder/" +
                (if (dlErrors.isNotEmpty()) "\n\nErrors:\n" + dlErrors.take(6).joinToString("\n") else "")
        }
        AlertDialog.Builder(this).setTitle("Download mudinjuduchu")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("OK", null).show()
    }

    // file download aagama atha idathula nikkirathai thavirkka
    private val watchdog = object : Runnable {
        override fun run() {
            if (dlRunning && fetching && System.currentTimeMillis() - lastAct > 60000) {
                finishFile(curSeq, "Timeout")
            }
            handler.postDelayed(this, 10000)
        }
    }
}
