package com.example.foldergrab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var urlBar: EditText

    private val exts = setOf("mp3", "m4a", "wav", "flac", "aac", "ogg", "wma",
        "mp4", "mkv", "webm", "avi", "mov", "3gp")

    private val ua = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private class Report {
        var pages = 0
        var links = 0
        val sample = ArrayList<String>()
        var error: String? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT in 23..28) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        urlBar = EditText(this).apply {
            hint = "Website URL paste pannunga"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> load(text.toString()); true }
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) { urlBar.setText(url) }
            }
            setOnLongClickListener {
                val r = hitTestResult
                val extra = r.extra
                when (r.type) {
                    WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                        if (extra != null) { confirmAndGrab(extra); true } else false
                    }
                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                        // Folder icon mela pidichaa: link URL-a vera vazhiya edukkanum
                        val msg = android.os.Handler(mainLooper) { m ->
                            val u = m.data.getString("url")
                            if (u != null) confirmAndGrab(u)
                            true
                        }.obtainMessage()
                        requestFocusNodeHref(msg)
                        true
                    }
                    else -> false
                }
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(urlBar, LinearLayout.LayoutParams(-1, -2))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    private fun load(input: String) {
        var u = input.trim()
        if (!u.startsWith("http")) u = "http://$u"
        web.loadUrl(u)
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    private fun confirmAndGrab(link: String) {
        AlertDialog.Builder(this)
            .setTitle("Files-a thedava?")
            .setMessage("$link\n\nIntha folder (subfolders ulla) la ulla media files-a thedi count kaattuven.")
            .setPositiveButton("Thedu") { _, _ -> grab(link) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun pathOf(u: String) = try { URL(u).path ?: "" } catch (e: Exception) { "" }
    private fun ext(u: String) = pathOf(u).substringAfterLast('.', "").lowercase()
    private fun lastSeg(u: String) = decode(pathOf(u).trimEnd('/').substringAfterLast('/'))

    private fun grab(link: String) {
        toast("Files-a thedureen...")
        Thread {
            val rep = Report()
            val found = LinkedHashMap<String, String>() // url -> relative folder
            try {
                if (ext(link) in exts) found[link] = ""
                else crawl(link, lastSeg(link) + "/", 0, found, HashSet(), rep)
            } catch (e: Exception) {
                rep.error = e.toString()
            }
            runOnUiThread { showResult(link, found, rep) }
        }.start()
    }

    private fun showResult(link: String, found: Map<String, String>, rep: Report) {
        if (found.isEmpty()) {
            val tv = TextView(this).apply {
                setPadding(40, 20, 40, 20)
                setTextIsSelectable(true)
                text = "Media files edhuvum kidaikala.\n\n" +
                    "Pages padichathu: ${rep.pages}\n" +
                    "Links kidaichathu: ${rep.links}\n" +
                    (rep.error?.let { "Error: $it\n" } ?: "") +
                    "\nSample links:\n" + rep.sample.joinToString("\n") +
                    "\n\nURL: $link"
            }
            AlertDialog.Builder(this).setTitle("Result").setView(tv)
                .setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("${found.size} files kidaichuduchu")
            .setMessage("Download aarambikkava?\n(Downloads/FolderGrab la save aagum)")
            .setPositiveButton("Download") { _, _ -> enqueueAll(link, found) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun enqueueAll(referer: String, found: Map<String, String>) {
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        for ((url, rel) in found) {
            val name = lastSeg(url).ifEmpty { "file" }
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "FolderGrab/$rel$name")
                .addRequestHeader("User-Agent", ua)
                .addRequestHeader("Referer", referer)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            dm.enqueue(req)
        }
        toast("${found.size} files download aaga aarambichuduchu")
    }

    private fun crawl(dir: String, rel: String, depth: Int,
                      out: MutableMap<String, String>, seen: MutableSet<String>, rep: Report) {
        if (depth > 8 || !seen.add(dir)) return
        val html: String
        val base: URL
        try {
            val c = URL(dir).openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 20000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "text/html,*/*")
            CookieManager.getInstance().getCookie(dir)?.let { c.setRequestProperty("Cookie", it) }
            html = c.inputStream.bufferedReader().use { it.readText() }
            base = c.url
        } catch (e: Exception) {
            rep.error = "${e.javaClass.simpleName}: ${e.message}"
            return
        }
        rep.pages++
        val dirPrefix = base.path.trimEnd('/') + "/"
        val re = Regex("""(?:href|src)\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        for (m in re.findAll(html)) {
            val href = m.groupValues[1].trim().replace("&amp;", "&")
            if (href.startsWith("#") || href.startsWith("javascript") || href.startsWith("mailto")) continue
            val full = try { URL(base, href).toString().substringBefore('#') } catch (e: Exception) { continue }
            rep.links++
            if (rep.sample.size < 8 && rep.links % 3 == 1) rep.sample.add(full)
            if (ext(full) in exts) {
                if (!out.containsKey(full)) out[full] = rel
                continue
            }
            // Subfolder: same host, intha folder-ku ulla, file extension illama
            val u = try { URL(full) } catch (e: Exception) { continue }
            if (u.host != base.host) continue
            val p = u.path
            val last = p.trimEnd('/').substringAfterLast('/')
            if (p.startsWith(dirPrefix) && p != dirPrefix && (p.endsWith("/") || !last.contains('.'))) {
                crawl(full, rel + decode(last) + "/", depth + 1, out, seen, rep)
            }
        }
    }

    private fun decode(s: String) =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }
            .replace(Regex("""[\\:*?"<>|]"""), "_")
}
