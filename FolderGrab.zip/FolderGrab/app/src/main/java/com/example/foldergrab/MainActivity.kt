package com.example.foldergrab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** ABH Browser: tabs, home screen, bookmarks, history, downloads, settings, desktop mode. */
class MainActivity : Activity() {

    companion object {
        const val CHANNEL = "abh_downloads"
        const val NOTIF_ID = 1
    }

    class Tab(val web: WebView) {
        var home = true
        var desktop = false
    }

    private lateinit var store: Store
    private lateinit var grabber: Grabber
    private val tabs = ArrayList<Tab>()
    private var cur = 0

    private lateinit var urlBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var content: FrameLayout
    private lateinit var tabBtn: TextView
    private lateinit var homeView: ScrollView
    private lateinit var homeLinks: LinearLayout
    private var listDlg: AlertDialog? = null

    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        grabber = Grabber(this, store)

        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT in 23..28) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)

        buildUi()
        newTab(null)
        val data = intent?.data
        if (intent?.action == Intent.ACTION_VIEW && data != null) go(data.toString())
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val data = intent?.data
        if (intent?.action == Intent.ACTION_VIEW && data != null) newTab(data.toString())
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onBackPressed() {
        val t = tabs[cur]
        if (!t.home && t.web.canGoBack()) t.web.goBack()
        else if (tabs.size > 1) closeTab(cur)
        else if (!t.home) { t.home = true; showTab() }
        else super.onBackPressed()
    }

    // ------------------------------------------------------------------
    //  UI
    // ------------------------------------------------------------------
    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // ---- top bar ----
        urlBar = EditText(this).apply {
            hint = "Search or type URL"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            textSize = 15f
            background = rounded(0xFFEFEFEF.toInt(), 22)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); true }
        }
        val reload = TextView(this).apply {
            text = "↻"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                val t = tabs[cur]
                if (!t.home) t.web.reload()
            }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(0), dp(6))
            addView(urlBar, LinearLayout.LayoutParams(0, -2, 1f))
            addView(reload, LinearLayout.LayoutParams(-2, -2))
        }
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(3)))

        // ---- content ----
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // hidden crawler/downloader browser
        root.addView(grabber.view, LinearLayout.LayoutParams(1, 1))

        // ---- bottom bar ----
        fun barBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { onClick() }
        }
        tabBtn = TextView(this).apply {
            text = "1"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.TRANSPARENT, 6, Color.DKGRAY)
            setOnClickListener { showTabs() }
        }
        val tabWrap = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(tabBtn, LinearLayout.LayoutParams(dp(28), dp(28)))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFFF3F3F3.toInt())
            addView(barBtn("←") { val t = tabs[cur]; if (!t.home && t.web.canGoBack()) t.web.goBack() },
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(barBtn("→") { val t = tabs[cur]; if (!t.home && t.web.canGoForward()) t.web.goForward() },
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(barBtn("🏠") { tabs[cur].home = true; showTab() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tabWrap, LinearLayout.LayoutParams(0, -1, 1f))
            addView(barBtn("⋮") { showMenu() }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, -2))

        buildHome()
        setContentView(root)
    }

    private fun buildHome() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        val logo = ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }
        col.addView(logo, LinearLayout.LayoutParams(dp(110), dp(110)))
        col.addView(TextView(this).apply {
            text = "ABH Browser"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(20))
        }, LinearLayout.LayoutParams(-1, -2))

        val search = EditText(this).apply {
            hint = "Search or type URL"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            textSize = 16f
            background = rounded(Color.WHITE, 26, 0xFFBDBDBD.toInt())
            setPadding(dp(20), dp(12), dp(20), dp(12))
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); v.text = ""; true }
        }
        col.addView(search, LinearLayout.LayoutParams(-1, -2))

        col.addView(TextView(this).apply {
            text = "Quick links"
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(dp(4), dp(24), 0, dp(6))
        }, LinearLayout.LayoutParams(-1, -2))

        homeLinks = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(homeLinks, LinearLayout.LayoutParams(-1, -2))

        homeView = ScrollView(this).apply { addView(col) }
    }

    private fun refreshHome() {
        val items = ArrayList<Store.Item>(store.bookmarks())
        val defaults = listOf(
            Store.Item("Google", "https://www.google.com"),
            Store.Item("YouTube", "https://m.youtube.com"),
            Store.Item("Wikipedia", "https://www.wikipedia.org"),
            Store.Item("GitHub", "https://github.com"))
        for (d in defaults) if (items.none { it.url == d.url }) items.add(d)
        homeLinks.removeAllViews()
        var i = 0
        while (i < items.size && i < 14) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0..1) {
                val lp = LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                if (i + j < items.size) {
                    val it2 = items[i + j]
                    row.addView(TextView(this).apply {
                        text = if (it2.title.length > 18) it2.title.substring(0, 18) + "…" else it2.title
                        gravity = Gravity.CENTER
                        textSize = 14f
                        background = rounded(0xFFF1F3F4.toInt(), 14)
                        setOnClickListener { go(it2.url) }
                    }, lp)
                } else {
                    row.addView(View(this), lp)
                }
            }
            homeLinks.addView(row, LinearLayout.LayoutParams(-1, -2))
            i += 2
        }
    }

    // ------------------------------------------------------------------
    //  Tabs
    // ------------------------------------------------------------------
    private fun isCur(v: WebView?): Boolean = v != null && tabs.isNotEmpty() && tabs[cur].web === v

    private fun makeWebView(): WebView {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url?.toString() ?: return false
                if (u.startsWith("http://") || u.startsWith("https://") ||
                    u.startsWith("about:") || u.startsWith("file:")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
                return true
            }

            override fun onPageStarted(v: WebView?, url: String?, favicon: Bitmap?) {
                if (isCur(v) && url != null) urlBar.setText(url)
            }

            override fun onPageFinished(v: WebView?, url: String?) {
                if (v == null || url == null) return
                if (isCur(v)) urlBar.setText(url)
                if (url.startsWith("http")) store.addHistory(v.title ?: url, url)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) {
                if (isCur(v)) {
                    progressBar.progress = p
                    progressBar.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                }
            }
        }
        // Long press: folder mela pidichaa full download
        w.setOnLongClickListener {
            val r = w.hitTestResult
            val extra = r.extra
            when (r.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) { grabber.confirmAndGrab(extra, w.url ?: extra); true } else false
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    val msg = Handler(mainLooper) { m ->
                        val u = m.data.getString("url")
                        if (u != null) grabber.confirmAndGrab(u, w.url ?: u)
                        true
                    }.obtainMessage()
                    w.requestFocusNodeHref(msg)
                    true
                }
                else -> false
            }
        }
        // Browser thaane download pannura files
        w.setDownloadListener { url, _, _, _, _ -> grabber.downloadSingle(url, w.url ?: url) }
        return w
    }

    private fun applyDesktop(t: Tab) {
        val s = t.web.settings
        if (t.desktop) {
            s.userAgentString = desktopUa
            s.loadWithOverviewMode = true
        } else {
            s.userAgentString = null
            s.loadWithOverviewMode = false
        }
    }

    private fun newTab(url: String?) {
        val t = Tab(makeWebView())
        t.desktop = store.desktopDefault
        applyDesktop(t)
        tabs.add(t)
        cur = tabs.size - 1
        if (url != null) {
            t.home = false
            showTab()
            urlBar.setText(url)
            t.web.loadUrl(url)
        } else {
            showTab()
        }
    }

    private fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        content.removeAllViews()
        val t = tabs.removeAt(i)
        t.web.destroy()
        if (tabs.isEmpty()) { newTab(null); return }
        if (i < cur) cur--
        if (cur >= tabs.size) cur = tabs.size - 1
        showTab()
    }

    private fun showTab() {
        val t = tabs[cur]
        content.removeAllViews()
        if (t.home) {
            refreshHome()
            content.addView(homeView, FrameLayout.LayoutParams(-1, -1))
            urlBar.setText("")
        } else {
            content.addView(t.web, FrameLayout.LayoutParams(-1, -1))
            urlBar.setText(t.web.url ?: "")
        }
        progressBar.visibility = View.GONE
        tabBtn.text = tabs.size.toString()
    }

    private fun resolve(q: String): String {
        if (q.startsWith("http://") || q.startsWith("https://") ||
            q.startsWith("file://") || q.startsWith("about:")) return q
        if (!q.contains(' ') && (q.contains('.') || q.startsWith("localhost"))) return "https://$q"
        return store.searchUrl(q)
    }

    private fun go(input: String) {
        val q = input.trim()
        if (q.isEmpty()) return
        val url = resolve(q)
        val t = tabs[cur]
        t.home = false
        showTab()
        urlBar.setText(url)
        urlBar.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
        t.web.loadUrl(url)
    }

    // ------------------------------------------------------------------
    //  Dialogs
    // ------------------------------------------------------------------
    private fun showList(
        title: String,
        labels: List<String>,
        onTap: (Int) -> Unit,
        onLong: ((Int) -> Unit)? = null,
        extra: Pair<String, () -> Unit>? = null
    ) {
        listDlg?.dismiss()
        val lv = ListView(this)
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val b = AlertDialog.Builder(this).setTitle(title).setView(lv).setPositiveButton("Close", null)
        if (extra != null) b.setNeutralButton(extra.first) { _, _ -> extra.second() }
        val d = b.create()
        lv.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); onTap(pos) }
        if (onLong != null) lv.setOnItemLongClickListener { _, _, pos, _ -> onLong(pos); true }
        listDlg = d
        d.show()
    }

    private fun showMenu() {
        val t = tabs[cur]
        val url = if (t.home) "" else (t.web.url ?: "")
        val bm = url.isNotEmpty() && store.isBookmarked(url)
        val labels = arrayOf(
            "➕  New tab",
            if (bm) "★  Remove bookmark" else "☆  Bookmark this page",
            "📚  Bookmarks",
            "🕘  History",
            "⬇  Downloads",
            if (t.desktop) "🖥  Desktop site: ON" else "🖥  Desktop site: OFF",
            "⚙  Settings")
        AlertDialog.Builder(this).setItems(labels) { _, i ->
            when (i) {
                0 -> newTab(null)
                1 -> toggleBookmark()
                2 -> showBookmarks()
                3 -> showHistory()
                4 -> grabber.showDownloads()
                5 -> {
                    t.desktop = !t.desktop
                    applyDesktop(t)
                    if (!t.home) t.web.reload()
                    toast("Desktop site " + (if (t.desktop) "ON" else "OFF"))
                }
                6 -> showSettings()
                else -> { }
            }
        }.show()
    }

    private fun toggleBookmark() {
        val t = tabs[cur]
        val url = t.web.url
        if (t.home || url == null) { toast("Bookmark panna page illa"); return }
        if (store.isBookmarked(url)) {
            store.removeBookmark(url); toast("Bookmark neekkapattathu")
        } else {
            store.addBookmark(t.web.title ?: url, url); toast("Bookmark save aachu")
        }
    }

    private fun showTabs() {
        val labels = tabs.mapIndexed { i, t ->
            (if (i == cur) "●  " else "○  ") +
                (if (t.home) "New tab" else (t.web.title?.takeIf { it.isNotEmpty() } ?: t.web.url ?: "Loading..."))
        }
        showList("Tabs  (long press = close)", labels,
            { i -> cur = i; showTab() },
            { i -> listDlg?.dismiss(); closeTab(i); showTabs() },
            Pair("New tab", { newTab(null) }))
    }

    private fun showBookmarks() {
        val l = store.bookmarks()
        if (l.isEmpty()) { toast("Bookmarks illa"); return }
        showList("Bookmarks  (long press = delete)",
            l.map { it.title + "\n" + it.url },
            { i -> go(l[i].url) },
            { i -> store.removeBookmark(l[i].url); toast("Neekkapattathu"); showBookmarks() })
    }

    private fun showHistory() {
        val l = store.history()
        if (l.isEmpty()) { toast("History illa"); return }
        showList("History", l.map { it.title + "\n" + it.url },
            { i -> go(l[i].url) }, null,
            Pair("Clear", { store.clearHistory(); toast("History azhichuduchu") }))
    }

    private fun showSettings() {
        val labels = listOf(
            "🔍  Search engine: " + store.engineNames[store.searchEngine],
            "🖥  Desktop site by default: " + (if (store.desktopDefault) "ON" else "OFF"),
            "⬇  Parallel downloads: " + store.dlConcurrency,
            "🕘  Clear history",
            "🧹  Clear cookies & cache",
            "♻  Forget downloaded list",
            "ℹ  About")
        showList("Settings", labels, { i ->
            when (i) {
                0 -> AlertDialog.Builder(this).setTitle("Search engine")
                    .setSingleChoiceItems(store.engineNames.toTypedArray(), store.searchEngine) { d, w ->
                        store.searchEngine = w; d.dismiss(); showSettings()
                    }.show()
                1 -> { store.desktopDefault = !store.desktopDefault; showSettings() }
                2 -> {
                    val opts = intArrayOf(1, 2, 4, 6)
                    AlertDialog.Builder(this).setTitle("Parallel downloads")
                        .setSingleChoiceItems(arrayOf("1", "2", "4", "6"),
                            maxOf(0, opts.indexOf(store.dlConcurrency))) { d, w ->
                            store.dlConcurrency = opts[w]; d.dismiss(); showSettings()
                        }.show()
                }
                3 -> { store.clearHistory(); toast("History azhichuduchu"); showSettings() }
                4 -> {
                    CookieManager.getInstance().removeAllCookies(null)
                    for (t in tabs) t.web.clearCache(true)
                    toast("Cookies & cache azhichuduchu"); showSettings()
                }
                5 -> { store.clearDone(); toast("Download list mariduchu"); showSettings() }
                6 -> AlertDialog.Builder(this).setTitle("ABH Browser")
                    .setMessage("Downloads: Downloads/ABH browser/\n\nFolder-a long press pannaa, ulla ella mp3/video-um download aagum.")
                    .setPositiveButton("OK", null).show()
                else -> { }
            }
        })
    }
}
