package com.example.foldergrab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URL
import java.net.URLDecoder

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var crawler: WebView   // maraivaana browser: pages-a padikka
    private lateinit var urlBar: EditText
    private val handler = Handler(Looper.getMainLooper())

    private val exts = setOf("mp3", "m4a", "wav", "flac", "aac", "ogg", "wma",
        "mp4", "mkv", "webm", "avi", "mov", "3gp")

    private class Job(val url: String, val rel: String, val depth: Int)
    private class Report {
        var pages = 0
        var links = 0
        var last: List<String> = emptyList()
        var error: String? = null
    }

    private val queue = ArrayList<Job>()
    private val seen = HashSet<String>()
    private val found = LinkedHashMap<String, String>() // url -> relative folder
    private var rep = Report()
    private var current: Job? = null
    private var running = false
    private var loadToken = 0
    private var scheduledToken = -1
    private var rootLink = ""
    private var progress: AlertDialog? = null
    private var progressText: TextView? = null

    private val js = """
(function(){
 var L=[],M={};
 document.querySelectorAll('a[href],[src],source,audio,video,[data-src],[data-url]').forEach(function(e){
   ['href','src','data-src','data-url'].forEach(function(a){
     var v=e.getAttribute(a);
     if(v){ try{ L.push(new URL(v,document.baseURI).href); }catch(x){} }
   });
 });
 var h=document.documentElement.outerHTML;
 var re=/["'(]([^"'()\s<>]+\.(?:mp3|m4a|wav|flac|aac|ogg|wma|mp4|mkv|webm|avi|mov|3gp)(?:\?[^"'()\s<>]*)?)["')]/gi, m;
 while((m=re.exec(h))){ try{ M[new URL(m[1].replace(/&amp;/g,'&'),document.baseURI).href]=1; }catch(x){} }
 return JSON.stringify({u:location.href,l:L,m:Object.keys(M)});
})()
"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT in 23..28) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        urlBar = EditText(this).apply {
            hint = "Website URL paste pannunga"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> load(text.toString()); true }
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) { urlBar.setText(url) }
            }
            setOnLongClickListener {
                val r = hitTestResult
                val extra = r.extra
                when (r.type) {
                    WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                        if (extra != null) { confirmAndGrab(extra); true } else false
                    }
                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                        val msg = Handler(mainLooper) { m ->
                            val u = m.data.getString("url")
                            if (u != null) confirmAndGrab(u)
                            true
                        }.obtainMessage()
                        requestFocusNodeHref(msg)
                        true
                    }
                    else -> false
                }
            }
        }
        crawler = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) { onCrawlLoaded() }
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(urlBar, LinearLayout.LayoutParams(-1, -2))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(crawler, LinearLayout.LayoutParams(1, 1))
        })
    }

    private fun load(input: String) {
        var u = input.trim()
        if (!u.startsWith("http")) u = "http://$u"
        web.loadUrl(u)
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- helpers ----------
    private fun pathOf(u: String) = try { URL(u).path ?: "" } catch (e: Exception) { "" }
    private fun extOf(s: String) = s.substringBefore('?').substringAfterLast('.', "").lowercase()

    private fun isMedia(u: String): Boolean {
        if (extOf(pathOf(u)) in exts) return true
        return try {
            val uri = Uri.parse(u)
            uri.queryParameterNames.any { extOf(uri.getQueryParameter(it) ?: "") in exts }
        } catch (e: Exception) { false }
    }

    private fun fileName(u: String): String {
        val p = pathOf(u).substringAfterLast('/')
        if (extOf(p) in exts) return decode(p)
        try {
            val uri = Uri.parse(u)
            for (n in uri.queryParameterNames) {
                val v = uri.getQueryParameter(n) ?: continue
                if (extOf(v) in exts) return decode(v.substringAfterLast('/'))
            }
        } catch (e: Exception) { }
        return decode(p).ifEmpty { "file" }
    }

    private fun folderName(u: String): String {
        val f = try { Uri.parse(u).getQueryParameter("folder") } catch (e: Exception) { null }
        val raw = f ?: pathOf(u)
        return decode(raw.trimEnd('/').substringAfterLast('/')).ifEmpty { "folder" }
    }

    private fun isSubfolder(cur: String, c: String): Boolean {
        val cu = try { URL(cur) } catch (e: Exception) { return false }
        val cc = try { URL(c) } catch (e: Exception) { return false }
        if (cu.host != cc.host) return false
        val cf = Uri.parse(cur).getQueryParameter("folder")
        val nf = Uri.parse(c).getQueryParameter("folder")
        if (nf != null && cf != null) {
            return cu.path == cc.path && nf.startsWith(cf.trimEnd('/') + "/") && nf != cf
        }
        val dirPrefix = cu.path.trimEnd('/') + "/"
        val last = cc.path.trimEnd('/').substringAfterLast('/')
        return cc.path.startsWith(dirPrefix) && cc.path != dirPrefix &&
            (cc.path.endsWith("/") || !last.contains('.'))
    }

    private fun decode(s: String) =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }
            .replace(Regex("""[\\:*?"<>|]"""), "_")

    // ---------- long press flow ----------
    private fun confirmAndGrab(link: String) {
        AlertDialog.Builder(this)
            .setTitle("Files-a thedava?")
            .setMessage("$link\n\nIntha folder (subfolders ulla) la ulla media files-a thedi count kaattuven.")
            .setPositiveButton("Thedu") { _, _ -> startCrawl(link) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startCrawl(link: String) {
        if (running) { toast("Munnaadi aarambicha vela innum odikittu irukku"); return }
        found.clear(); seen.clear(); queue.clear(); rep = Report()
        rootLink = link
        if (isMedia(link)) {
            found[link] = ""
            showResult(link, LinkedHashMap(found), rep)
            return
        }
        running = true
        queue.add(Job(link, folderName(link) + "/", 0))
        progressText = TextView(this).apply { setPadding(48, 32, 48, 16); text = "Thedureen..." }
        progress = AlertDialog.Builder(this)
            .setTitle("Files-a thedureen")
            .setView(progressText)
            .setCancelable(false)
            .setNegativeButton("Stop") { _, _ -> if (running) finishCrawl() }
            .show()
        next()
    }

    private fun next() {
        if (!running) return
        var job: Job? = null
        while (queue.isNotEmpty()) {
            val j = queue.removeAt(0)
            if (j.depth <= 8 && seen.add(j.url)) { job = j; break }
        }
        if (job == null) { finishCrawl(); return }
        current = job
        val t = ++loadToken
        progressText?.text = "Pages: ${rep.pages}   Files: ${found.size}\n\n${job.rel}"
        crawler.loadUrl(job.url)
        // page romba neram load aanaalum edukka try pannum
        handler.postDelayed({
            if (running && t == loadToken) { scheduledToken = t; extract(t) }
        }, 30000)
    }

    private fun onCrawlLoaded() {
        if (!running || current == null) return
        val t = loadToken
        if (scheduledToken == t) return
        scheduledToken = t
        handler.postDelayed({ extract(t) }, 800) // JavaScript load aaga konjam neram
    }

    private fun extract(t: Int) {
        if (!running || t != loadToken) return
        crawler.evaluateJavascript(js) { res -> onExtracted(t, res) }
    }

    private fun onExtracted(t: Int, res: String?) {
        if (!running || t != loadToken) return
        loadToken++
        val job = current ?: return
        try {
            val s = JSONTokener(res ?: "null").nextValue()
            if (s is String) handlePage(job, JSONObject(s)) else rep.error = "Page data kidaikala"
        } catch (e: Exception) {
            rep.error = e.toString()
        }
        handler.post { next() }
    }

    private fun handlePage(job: Job, o: JSONObject) {
        val pageUrl = o.optString("u", job.url)
        val links = o.getJSONArray("l")
        val media = o.getJSONArray("m")
        rep.pages++
        val uniq = LinkedHashSet<String>()
        for (i in 0 until links.length()) uniq.add(links.getString(i).substringBefore('#'))
        rep.links += uniq.size
        rep.last = uniq.toList().takeLast(15)
        for (i in 0 until media.length()) {
            val m = media.getString(i)
            if (!found.containsKey(m)) found[m] = job.rel
        }
        for (l in uniq) {
            if (isMedia(l)) {
                if (!found.containsKey(l)) found[l] = job.rel
            } else if (isSubfolder(pageUrl, l)) {
                queue.add(Job(l, job.rel + folderName(l) + "/", job.depth + 1))
            }
        }
    }

    private fun finishCrawl() {
        running = false
        current = null
        loadToken++
        handler.removeCallbacksAndMessages(null)
        progress?.dismiss(); progress = null
        showResult(rootLink, LinkedHashMap(found), rep)
    }

    private fun showResult(link: String, files: Map<String, String>, r: Report) {
        if (files.isEmpty()) {
            val tv = TextView(this).apply {
                setPadding(40, 20, 40, 20)
                setTextIsSelectable(true)
                text = "Media files edhuvum kidaikala.\n\n" +
                    "Pages padichathu: ${r.pages}\n" +
                    "Links kidaichathu: ${r.links}\n" +
                    (r.error?.let { "Error: $it\n" } ?: "") +
                    "\nKadaisi page-oda links:\n" + r.last.joinToString("\n") +
                    "\n\nURL: $link"
            }
            AlertDialog.Builder(this).setTitle("Result").setView(android.widget.ScrollView(this).apply { addView(tv) })
                .setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("${files.size} files kidaichuduchu")
            .setMessage("Download aarambikkava?\n(Downloads/FolderGrab la save aagum)")
            .setPositiveButton("Download") { _, _ -> enqueueAll(link, files) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun enqueueAll(referer: String, files: Map<String, String>) {
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val ua = web.settings.userAgentString
        for ((url, rel) in files) {
            val name = fileName(url)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "FolderGrab/$rel$name")
                .addRequestHeader("User-Agent", ua)
                .addRequestHeader("Referer", referer)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            dm.enqueue(req)
        }
        toast("${files.size} files download aaga aarambichuduchu")
    }
}
