package com.example.foldergrab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** ABH Browser: tabs, home screen, bookmarks, history, downloads, theme, desktop mode. */
class MainActivity : Activity() {

    companion object {
        const val CHANNEL = "abh_downloads"
        const val NOTIF_ID = 1
    }

    /** Page-la kandupidicha video/audio URLs (ovoru tab-kum) */
    class Sniffed { val urls = LinkedHashSet<String>() }

    class Tab(val web: WebView) {
        var home = true
        var desktop = false
    }

    private lateinit var store: Store
    private lateinit var grabber: Grabber
    private lateinit var pal: Palette
    private val tabs = ArrayList<Tab>()
    private var cur = 0

    private lateinit var urlBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var content: FrameLayout
    private lateinit var tabIcon: IconView
    private lateinit var starIcon: IconView
    private lateinit var menuBtn: FrameLayout
    private lateinit var mediaBadge: TextView
    private lateinit var homeView: ScrollView
    private lateinit var homeLinks: LinearLayout
    private var listDlg: AlertDialog? = null
    private var lastX = 0f
    private var lastY = 0f

    private val gold = 0xFFFFC107.toInt()
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        store = Store(this)
        pal = store.palette()
        setTheme(if (pal.dark) android.R.style.Theme_Material_NoActionBar
                 else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        grabber = Grabber(this, store)
        grabber.onOpenPage = { u -> go(u) }

        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT in 23..28) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)

        buildUi()
        restoreOrNew()
        val data = intent?.data
        if (intent?.action == Intent.ACTION_VIEW && data != null) go(data.toString())
        if (intent?.getBooleanExtra("open_downloads", false) == true) grabber.showDownloads()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val data = intent?.data
        if (intent?.action == Intent.ACTION_VIEW && data != null) newTab(data.toString())
        if (intent?.getBooleanExtra("open_downloads", false) == true) grabber.showDownloads()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Auto theme: phone-oda day/night maarunaa app-um maarum
        if (store.theme == 0 && store.palette().dark != pal.dark && !grabber.isBusy()) {
            saveTabsAndRecreate()
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onBackPressed() {
        val t = tabs[cur]
        if (!t.home && t.web.canGoBack()) t.web.goBack()
        else if (tabs.size > 1) closeTab(cur)
        else if (!t.home) { t.home = true; showTab() }
        else super.onBackPressed()
    }

    private fun saveTabsAndRecreate() {
        store.savedTabs = tabs.joinToString("\n") { if (it.home) "" else (it.web.url ?: "") }
        store.savedCur = cur
        store.restoreFlag = true
        recreate()
    }

    private fun restoreOrNew() {
        val saved = store.savedTabs
        if (store.restoreFlag && saved.isNotEmpty()) {
            store.restoreFlag = false
            for (u in saved.split("\n")) newTab(if (u.isEmpty()) null else u)
            cur = store.savedCur.coerceIn(0, tabs.size - 1)
            showTab()
        } else {
            store.restoreFlag = false
            newTab(null)
        }
    }

    // ------------------------------------------------------------------
    //  UI
    // ------------------------------------------------------------------
    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun iconBtn(icon: IconView, onClick: () -> Unit): FrameLayout = FrameLayout(this).apply {
        addView(icon, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        // hidden crawler/downloader browser-a pazhaya parent-la irundhu eduthu
        (grabber.view.parent as? ViewGroup)?.removeView(grabber.view)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bar)
        }

        // ---- top bar: [search] [reload] [star] [download] ----
        urlBar = EditText(this).apply {
            hint = "Search or type URL"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(pal.text)
            setHintTextColor(pal.sub)
            background = rounded(pal.field, 22)
            setPadding(dp(16), 0, dp(16), 0)
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); true }
        }
        starIcon = IconView(this, IconView.STAR, pal.text)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(pal.bar)
            setPadding(dp(10), dp(8), dp(4), dp(8))
        }
        top.addView(urlBar, LinearLayout.LayoutParams(0, dp(44), 1f))
        top.addView(iconBtn(IconView(this, IconView.RELOAD, pal.text)) {
            val t = tabs[cur]
            if (!t.home) t.web.reload()
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(iconBtn(starIcon) { toggleBookmark() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(iconBtn(IconView(this, IconView.DOWNLOAD, pal.text)) { grabber.showDownloads() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(3)))

        // ---- content ----
        content = FrameLayout(this).apply { setBackgroundColor(pal.bg) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // hidden crawler/downloader browser
        root.addView(grabber.view, LinearLayout.LayoutParams(1, 1))

        // ---- bottom bar: [<] [>] [home] [+] [tabs] [menu] ----
        tabIcon = IconView(this, IconView.TABS, pal.text)
        tabIcon.label = "1"
        menuBtn = iconBtn(IconView(this, IconView.DOTS, pal.text)) { showMenu(menuBtn) }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(pal.bar)
        }
        val lp = { LinearLayout.LayoutParams(0, dp(54), 1f) }
        bottom.addView(iconBtn(IconView(this, IconView.BACK, pal.text)) {
            val t = tabs[cur]
            if (!t.home && t.web.canGoBack()) t.web.goBack()
        }, lp())
        bottom.addView(iconBtn(IconView(this, IconView.FORWARD, pal.text)) {
            val t = tabs[cur]
            if (!t.home && t.web.canGoForward()) t.web.goForward()
        }, lp())
        bottom.addView(iconBtn(IconView(this, IconView.HOME, pal.text)) {
            tabs[cur].home = true
            showTab()
        }, lp())
        bottom.addView(iconBtn(IconView(this, IconView.PLUS, pal.text)) { newTab(null) }, lp())
        bottom.addView(iconBtn(tabIcon) { showTabs() }, lp())
        bottom.addView(menuBtn, lp())
        root.addView(bottom, LinearLayout.LayoutParams(-1, -2))

        mediaBadge = TextView(this).apply {
            text = "⬇"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(0xFF1E88E5.toInt(), 24)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            elevation = dp(6).toFloat()
            visibility = View.GONE
            setOnClickListener { showDetected() }
        }

        buildHome()
        setContentView(root)

        // status bar / navigation bar colour
        window.statusBarColor = pal.bar
        window.navigationBarColor = pal.bar
        var flags = window.decorView.systemUiVisibility
        flags = if (pal.dark) flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                else flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= 26) {
            flags = if (pal.dark) flags and 0x10.inv() else flags or 0x10
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun buildHome() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        val logo = ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }
        col.addView(logo, LinearLayout.LayoutParams(dp(110), dp(110)))
        col.addView(TextView(this).apply {
            text = "ABH Browser"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(pal.sub)
            setPadding(0, dp(8), 0, dp(20))
        }, LinearLayout.LayoutParams(-1, -2))

        val search = EditText(this).apply {
            hint = "Search or type URL"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            textSize = 16f
            setTextColor(pal.text)
            setHintTextColor(pal.sub)
            background = rounded(Color.TRANSPARENT, 26, pal.stroke)
            setPadding(dp(20), dp(12), dp(20), dp(12))
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); v.text = ""; true }
        }
        col.addView(search, LinearLayout.LayoutParams(-1, -2))

        col.addView(TextView(this).apply {
            text = "Quick links"
            textSize = 14f
            setTextColor(pal.sub)
            setPadding(dp(4), dp(28), 0, dp(8))
        }, LinearLayout.LayoutParams(-1, -2))

        homeLinks = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(homeLinks, LinearLayout.LayoutParams(-1, -2))

        homeView = ScrollView(this).apply { addView(col) }
    }

    private fun refreshHome() {
        val items = ArrayList<Store.Item>(store.bookmarks())
        val defaults = listOf(
            Store.Item("Google", "https://www.google.com"),
            Store.Item("YouTube", "https://m.youtube.com"),
            Store.Item("Wikipedia", "https://www.wikipedia.org"),
            Store.Item("GitHub", "https://github.com"))
        for (d in defaults) if (items.none { it.url == d.url }) items.add(d)
        homeLinks.removeAllViews()
        var i = 0
        while (i < items.size && i < 14) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0..1) {
                val lp = LinearLayout.LayoutParams(0, dp(62), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                if (i + j < items.size) {
                    val item = items[i + j]
                    row.addView(TextView(this).apply {
                        text = if (item.title.length > 18) item.title.substring(0, 18) + "…" else item.title
                        gravity = Gravity.CENTER
                        textSize = 17f
                        setTextColor(pal.text)
                        background = rounded(pal.tile, 18)
                        setOnClickListener { go(item.url) }
                    }, lp)
                } else {
                    row.addView(View(this), lp)
                }
            }
            homeLinks.addView(row, LinearLayout.LayoutParams(-1, -2))
            i += 2
        }
    }

    private fun updateStar() {
        val t = tabs.getOrNull(cur)
        val url = if (t == null || t.home) null else t.web.url
        val on = url != null && store.isBookmarked(url)
        starIcon.filled = on
        starIcon.tint = if (on) gold else pal.text
        starIcon.invalidate()
    }

    // ------------------------------------------------------------------
    //  Tabs
    // ------------------------------------------------------------------
    private fun isCur(v: WebView?): Boolean = v != null && tabs.isNotEmpty() && tabs[cur].web === v

    private fun makeWebView(): WebView {
        val w = WebView(this)
        w.tag = Sniffed()
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url?.toString() ?: return false
                if (u.startsWith("http://") || u.startsWith("https://") ||
                    u.startsWith("about:") || u.startsWith("file:")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
                return true
            }

            override fun onPageStarted(v: WebView?, url: String?, favicon: Bitmap?) {
                (v?.tag as? Sniffed)?.let { sn -> synchronized(sn.urls) { sn.urls.clear() } }
                if (isCur(v)) { if (url != null) urlBar.setText(url); updateBadge() }
            }

            // Page-la odura video/audio links-a kandupidikkum (background thread)
            override fun shouldInterceptRequest(v: WebView?, req: WebResourceRequest?): WebResourceResponse? {
                val u = req?.url?.toString()
                val sn = w.tag as? Sniffed
                if (u != null && sn != null && grabber.sniffable(u)) {
                    var added = false
                    synchronized(sn.urls) { if (sn.urls.size < 40 && sn.urls.add(u)) added = true }
                    if (added) runOnUiThread { updateBadge() }
                }
                return null
            }

            override fun onPageFinished(v: WebView?, url: String?) {
                if (v == null || url == null) return
                if (isCur(v)) { urlBar.setText(url); updateStar() }
                if (url.startsWith("http")) store.addHistory(v.title ?: url, url)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) {
                if (isCur(v)) {
                    progressBar.progress = p
                    progressBar.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                }
            }
        }
        // Long press: folder / video mela pidichaa download
        w.setOnLongClickListener {
            val r = w.hitTestResult
            val extra = r.extra
            when (r.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) { grabber.confirmAndGrab(extra, w.url ?: extra); true } else false
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    val msg = Handler(mainLooper) { m ->
                        val u = m.data.getString("url")
                        if (u != null) grabber.confirmAndGrab(u, w.url ?: u)
                        true
                    }.obtainMessage()
                    w.requestFocusNodeHref(msg)
                    true
                }
                WebView.HitTestResult.UNKNOWN_TYPE -> {
                    // Video mela long press-a irukkalaam: JS-la check pannum
                    val sn = w.tag as? Sniffed
                    val sniffed = ArrayList<String>()
                    if (sn != null) synchronized(sn.urls) { sniffed.addAll(sn.urls) }
                    grabber.videoAt(w, lastX, lastY, sniffed)
                    false
                }
                else -> false
            }
        }
        w.setOnTouchListener { _, ev -> lastX = ev.x; lastY = ev.y; false }
        // Browser thaane download pannura files
        w.setDownloadListener { url, _, _, _, _ -> grabber.downloadSingle(url, w.url ?: url) }
        return w
    }

    private fun applyDesktop(t: Tab) {
        val s = t.web.settings
        if (t.desktop) {
            s.userAgentString = desktopUa
            s.loadWithOverviewMode = true
        } else {
            s.userAgentString = null
            s.loadWithOverviewMode = false
        }
    }

    private fun newTab(url: String?) {
        val t = Tab(makeWebView())
        t.desktop = store.desktopDefault
        applyDesktop(t)
        tabs.add(t)
        cur = tabs.size - 1
        if (url != null) {
            t.home = false
            showTab()
            urlBar.setText(url)
            t.web.loadUrl(url)
        } else {
            showTab()
        }
    }

    private fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        content.removeAllViews()
        val t = tabs.removeAt(i)
        t.web.destroy()
        if (tabs.isEmpty()) { newTab(null); return }
        if (i < cur) cur--
        if (cur >= tabs.size) cur = tabs.size - 1
        showTab()
    }

    private fun showTab() {
        val t = tabs[cur]
        content.removeAllViews()
        if (t.home) {
            refreshHome()
            content.addView(homeView, FrameLayout.LayoutParams(-1, -1))
            urlBar.setText("")
        } else {
            content.addView(t.web, FrameLayout.LayoutParams(-1, -1))
            content.addView(mediaBadge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(24))
            })
            urlBar.setText(t.web.url ?: "")
        }
        progressBar.visibility = View.GONE
        tabIcon.label = tabs.size.toString()
        tabIcon.invalidate()
        updateStar()
        updateBadge()
    }

    private fun updateBadge() {
        val t = tabs.getOrNull(cur)
        val sn = t?.web?.tag as? Sniffed
        var n = 0
        if (t != null && !t.home && sn != null) synchronized(sn.urls) { n = sn.urls.size }
        if (n > 0) {
            mediaBadge.text = "⬇   $n video"
            mediaBadge.visibility = View.VISIBLE
        } else {
            mediaBadge.visibility = View.GONE
        }
    }

    private fun showDetected() {
        val t = tabs[cur]
        val sn = t.web.tag as? Sniffed ?: return
        val urls = ArrayList<String>()
        synchronized(sn.urls) { urls.addAll(sn.urls) }
        if (urls.isEmpty()) return
        grabber.presentDetected(urls, t.web.url ?: "", t.web.title ?: "video")
    }

    private fun resolve(q: String): String {
        if (q.startsWith("http://") || q.startsWith("https://") ||
            q.startsWith("file://") || q.startsWith("about:")) return q
        if (!q.contains(' ') && (q.contains('.') || q.startsWith("localhost"))) return "https://$q"
        return store.searchUrl(q)
    }

    private fun go(input: String) {
        val q = input.trim()
        if (q.isEmpty()) return
        val url = resolve(q)
        val t = tabs[cur]
        t.home = false
        showTab()
        urlBar.setText(url)
        urlBar.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
        t.web.loadUrl(url)
    }

    // ------------------------------------------------------------------
    //  Menu & dialogs
    // ------------------------------------------------------------------
    private fun showList(
        title: String,
        labels: List<String>,
        onTap: (Int) -> Unit,
        onLong: ((Int) -> Unit)? = null,
        extra: Pair<String, () -> Unit>? = null
    ) {
        listDlg?.dismiss()
        val lv = ListView(this)
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val b = AlertDialog.Builder(this).setTitle(title).setView(lv).setPositiveButton("Close", null)
        if (extra != null) b.setNeutralButton(extra.first) { _, _ -> extra.second() }
        val d = b.create()
        lv.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); onTap(pos) }
        if (onLong != null) lv.setOnItemLongClickListener { _, _, pos, _ -> onLong(pos); true }
        listDlg = d
        d.show()
    }

    private fun showMenu(anchor: View) {
        val t = tabs[cur]
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(pal.menu, 14)
            setPadding(0, dp(6), 0, dp(6))
        }
        val width = dp(290)
        val pw = PopupWindow(col, width, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.elevation = dp(10).toFloat()

        fun row(label: String, trailing: View?, onClick: () -> Unit) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), dp(14), dp(16), dp(14))
                addView(TextView(this@MainActivity).apply {
                    text = label
                    textSize = 16f
                    setTextColor(pal.text)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                if (trailing != null) addView(trailing, LinearLayout.LayoutParams(-2, -2))
                setOnClickListener { pw.dismiss(); onClick() }
            }
            col.addView(r, LinearLayout.LayoutParams(-1, -2))
        }

        row("Bookmarks", null) { showBookmarks() }
        row("History", null) { showHistory() }
        row("Downloads", null) { grabber.showDownloads() }
        val cb = CheckBox(this).apply { isChecked = t.desktop; isClickable = false; isFocusable = false }
        row("Desktop mode", cb) { toggleDesktop() }
        row("Theme (Day / Night / Auto)", null) { showThemeChooser() }
        row("Settings", null) { showSettings() }

        col.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val x = resources.displayMetrics.widthPixels - width - dp(8)
        val y = maxOf(dp(8), loc[1] - col.measuredHeight - dp(8))
        pw.showAtLocation(anchor.rootView, Gravity.NO_GRAVITY, x, y)
    }

    private fun toggleDesktop() {
        val t = tabs[cur]
        t.desktop = !t.desktop
        applyDesktop(t)
        if (!t.home) t.web.reload()
        toast("Desktop mode " + (if (t.desktop) "ON" else "OFF"))
    }

    private fun showThemeChooser() {
        if (grabber.isBusy()) { toast("Download mudinjadhum theme maathunga"); return }
        val names = arrayOf("Day", "Night", "Auto")
        val codes = intArrayOf(1, 2, 0)
        AlertDialog.Builder(this).setTitle("Theme")
            .setSingleChoiceItems(names, maxOf(0, codes.indexOf(store.theme))) { d, w ->
                d.dismiss()
                store.theme = codes[w]
                saveTabsAndRecreate()
            }.show()
    }

    private fun toggleBookmark() {
        val t = tabs[cur]
        val url = t.web.url
        if (t.home || url == null) { toast("Bookmark panna page illa"); return }
        if (store.isBookmarked(url)) {
            store.removeBookmark(url); toast("Bookmark neekkapattathu")
        } else {
            store.addBookmark(t.web.title ?: url, url); toast("Bookmark save aachu")
        }
        updateStar()
    }

    private fun showTabs() {
        val labels = tabs.mapIndexed { i, t ->
            (if (i == cur) "●  " else "○  ") +
                (if (t.home) "New tab" else (t.web.title?.takeIf { it.isNotEmpty() } ?: t.web.url ?: "Loading..."))
        }
        showList("Tabs  (long press = close)", labels,
            { i -> cur = i; showTab() },
            { i -> listDlg?.dismiss(); closeTab(i); showTabs() },
            Pair("New tab", { newTab(null) }))
    }

    private fun showBookmarks() {
        val l = store.bookmarks()
        if (l.isEmpty()) { toast("Bookmarks illa"); return }
        showList("Bookmarks  (long press = delete)",
            l.map { it.title + "\n" + it.url },
            { i -> go(l[i].url) },
            { i -> store.removeBookmark(l[i].url); toast("Neekkapattathu"); showBookmarks(); updateStar() })
    }

    private fun showHistory() {
        val l = store.history()
        if (l.isEmpty()) { toast("History illa"); return }
        showList("History", l.map { it.title + "\n" + it.url },
            { i -> go(l[i].url) }, null,
            Pair("Clear", { store.clearHistory(); toast("History azhichuduchu") }))
    }

    private fun showSettings() {
        val labels = listOf(
            "Search engine: " + store.engineNames[store.searchEngine],
            "Desktop mode by default: " + (if (store.desktopDefault) "ON" else "OFF"),
            "Parallel downloads: " + store.dlConcurrency,
            "Clear history",
            "Clear cookies & cache",
            "Forget downloaded list",
            "About")
        showList("Settings", labels, { i ->
            when (i) {
                0 -> AlertDialog.Builder(this).setTitle("Search engine")
                    .setSingleChoiceItems(store.engineNames.toTypedArray(), store.searchEngine) { d, w ->
                        store.searchEngine = w; d.dismiss(); showSettings()
                    }.show()
                1 -> { store.desktopDefault = !store.desktopDefault; showSettings() }
                2 -> {
                    val opts = intArrayOf(1, 2, 4, 6)
                    AlertDialog.Builder(this).setTitle("Parallel downloads")
                        .setSingleChoiceItems(arrayOf("1", "2", "4", "6"),
                            maxOf(0, opts.indexOf(store.dlConcurrency))) { d, w ->
                            store.dlConcurrency = opts[w]; d.dismiss(); showSettings()
                        }.show()
                }
                3 -> { store.clearHistory(); toast("History azhichuduchu"); showSettings() }
                4 -> {
                    CookieManager.getInstance().removeAllCookies(null)
                    for (t in tabs) t.web.clearCache(true)
                    toast("Cookies & cache azhichuduchu"); showSettings()
                }
                5 -> { store.clearDone(); toast("Download list mariduchu"); showSettings() }
                6 -> AlertDialog.Builder(this).setTitle("ABH Browser")
                    .setMessage("Downloads: Downloads/ABH browser/\n\nFolder-a long press pannaa, ulla ella mp3/video-um download aagum.")
                    .setPositiveButton("OK", null).show()
                else -> { }
            }
        })
    }
}
